<?xml version="1.0" encoding="UTF-8"?>
<museScore version="4.60">
  <Style>
    <pageWidth>8.26772</pageWidth>
    <pageHeight>11.6929</pageHeight>
    <pagePrintableWidth>7.08661</pagePrintableWidth>
    <pageEvenLeftMargin>0.590551</pageEvenLeftMargin>
    <pageOddLeftMargin>0.590551</pageOddLeftMargin>
    <pageEvenTopMargin>0.590551</pageEvenTopMargin>
    <pageEvenBottomMargin>0.590551</pageEvenBottomMargin>
    <pageOddTopMargin>0.590551</pageOddTopMargin>
    <pageOddBottomMargin>0.590551</pageOddBottomMargin>
    <pageTwosided>1</pageTwosided>
    <staffUpperBorder>7</staffUpperBorder>
    <staffLowerBorder>7</staffLowerBorder>
    <staffHeaderFooterPadding>1</staffHeaderFooterPadding>
    <staffDistance>6.5</staffDistance>
    <instrumentNameOffset>1</instrumentNameOffset>
    <akkoladeDistance>6.5</akkoladeDistance>
    <minSystemDistance>8.5</minSystemDistance>
    <maxSystemDistance>15</maxSystemDistance>
    <alignSystemToMargin>1</alignSystemToMargin>
    <enableVerticalSpread>1</enableVerticalSpread>
    <spreadSystem>2.5</spreadSystem>
    <spreadSquareBracket>1.2</spreadSquareBracket>
    <spreadCurlyBracket>1.1</spreadCurlyBracket>
    <minSystemSpread>8.5</minSystemSpread>
    <maxSystemSpread>32</maxSystemSpread>
    <minStaffSpread>3.5</minStaffSpread>
    <maxStaffSpread>20</maxStaffSpread>
    <maxAkkoladeDistance>6.5</maxAkkoladeDistance>
    <maxPageFillSpread>6</maxPageFillSpread>
    <lyricsPlacement>1</lyricsPlacement>
    <lyricsPosAbove x="0" y="-2"/>
    <lyricsPosBelow x="0" y="3"/>
    <lyricsMinTopDistance>1</lyricsMinTopDistance>
    <lyricsMinBottomDistance>2</lyricsMinBottomDistance>
    <lyricsMinDistance>0.25</lyricsMinDistance>
    <lyricsLineHeight>1</lyricsLineHeight>
    <lyricsDashMinLength>0.4</lyricsDashMinLength>
    <lyricsDashMaxLength>0.8</lyricsDashMaxLength>
    <lyricsDashMaxDistance>16</lyricsDashMaxDistance>
    <lyricsDashForce>1</lyricsDashForce>
    <lyricsDashFirstAndLastGapAreHalf>1</lyricsDashFirstAndLastGapAreHalf>
    <lyricsAlignVerseNumber>1</lyricsAlignVerseNumber>
    <lyricsLineThickness>0.3</lyricsLineThickness>
    <lyricsMelismaAlign>left,baseline</lyricsMelismaAlign>
    <lyricsMelismaPad>0.1</lyricsMelismaPad>
    <lyricsDashPad>0.05</lyricsDashPad>
    <lyricsDashLineThickness>0.15</lyricsDashLineThickness>
    <lyricsDashYposRatio>0.6</lyricsDashYposRatio>
    <lyricsShowDashIfSyllableOnFirstNote>1</lyricsShowDashIfSyllableOnFirstNote>
    <lyricsMelismaForce>0</lyricsMelismaForce>
    <lyricsMelismaMinLength>1</lyricsMelismaMinLength>
    <lyricsDashPosAtStartOfSystem>0</lyricsDashPosAtStartOfSystem>
    <lyricsAvoidBarlines>1</lyricsAvoidBarlines>
    <lyricsLimitDashCount>0</lyricsLimitDashCount>
    <lyricsMaxDashCount>1</lyricsMaxDashCount>
    <lyricsCenterDashedSyllables>0</lyricsCenterDashedSyllables>
    <lyricsOddFontFace>MuseJazz Text</lyricsOddFontFace>
    <lyricsOddFontSize>10</lyricsOddFontSize>
    <lyricsOddLineSpacing>1</lyricsOddLineSpacing>
    <lyricsOddFontSpatiumDependent>1</lyricsOddFontSpatiumDependent>
    <lyricsOddFontStyle>0</lyricsOddFontStyle>
    <lyricsOddColor r="0" g="0" b="0" a="255"/>
    <lyricsOddAlign>center,baseline</lyricsOddAlign>
    <lyricsOddFrameType>0</lyricsOddFrameType>
    <lyricsOddFramePadding>0.2</lyricsOddFramePadding>
    <lyricsOddFrameWidth>0.1</lyricsOddFrameWidth>
    <lyricsOddFrameRound>0</lyricsOddFrameRound>
    <lyricsOddFrameFgColor r="0" g="0" b="0" a="255"/>
    <lyricsOddFrameBgColor r="255" g="255" b="255" a="0"/>
    <lyricsOddPosition>center</lyricsOddPosition>
    <lyricsEvenFontFace>MuseJazz Text</lyricsEvenFontFace>
    <lyricsEvenFontSize>10</lyricsEvenFontSize>
    <lyricsEvenLineSpacing>1</lyricsEvenLineSpacing>
    <lyricsEvenFontSpatiumDependent>1</lyricsEvenFontSpatiumDependent>
    <lyricsEvenFontStyle>0</lyricsEvenFontStyle>
    <lyricsEvenColor r="0" g="0" b="0" a="255"/>
    <lyricsEvenAlign>center,baseline</lyricsEvenAlign>
    <lyricsEvenFrameType>0</lyricsEvenFrameType>
    <lyricsEvenFramePadding>0.2</lyricsEvenFramePadding>
    <lyricsEvenFrameWidth>0.1</lyricsEvenFrameWidth>
    <lyricsEvenFrameRound>0</lyricsEvenFrameRound>
    <lyricsEvenFrameFgColor r="0" g="0" b="0" a="255"/>
    <lyricsEvenFrameBgColor r="255" g="255" b="255" a="0"/>
    <lyricsEvenPosition>center</lyricsEvenPosition>
    <figuredBassFontFamily>MScoreBC</figuredBassFontFamily>
    <figuredBassYOffset>6</figuredBassYOffset>
    <figuredBassLineHeight>1</figuredBassLineHeight>
    <figuredBassAlignment>0</figuredBassAlignment>
    <figuredBassStyle>0</figuredBassStyle>
    <systemFrameDistance>7</systemFrameDistance>
    <frameSystemDistance>7</frameSystemDistance>
    <paddingToNotationAbove>2</paddingToNotationAbove>
    <paddingToNotationBelow>2</paddingToNotationBelow>
    <minMeasureWidth>5</minMeasureWidth>
    <barWidth>0.3</barWidth>
    <doubleBarWidth>0.3</doubleBarWidth>
    <endBarWidth>0.6</endBarWidth>
    <doubleBarDistance>0.3</doubleBarDistance>
    <endBarDistance>0.3</endBarDistance>
    <repeatBarlineDotSeparation>0.00698057</repeatBarlineDotSeparation>
    <repeatBarTips>1</repeatBarTips>
    <startBarlineSingle>0</startBarlineSingle>
    <startBarlineMultiple>1</startBarlineMultiple>
    <maskBarlinesForText>0</maskBarlinesForText>
    <bracketWidth>0.44</bracketWidth>
    <bracketDistance>0.45</bracketDistance>
    <akkoladeWidth>1.6</akkoladeWidth>
    <akkoladeBarDistance>0.4</akkoladeBarDistance>
    <dividerLeft>0</dividerLeft>
    <dividerLeftSym>systemDivider</dividerLeftSym>
    <dividerLeftX>0</dividerLeftX>
    <dividerLeftY>0</dividerLeftY>
    <dividerRight>0</dividerRight>
    <dividerRightSym>systemDivider</dividerRightSym>
    <dividerRightX>0</dividerRightX>
    <dividerRightY>0</dividerRightY>
    <clefLeftMargin>0.8</clefLeftMargin>
    <keysigLeftMargin>0.5</keysigLeftMargin>
    <ambitusMargin>0.5</ambitusMargin>
    <timesigLeftMargin>0.63</timesigLeftMargin>
    <midClefKeyRightMargin>1</midClefKeyRightMargin>
    <clefKeyRightMargin>0.8</clefKeyRightMargin>
    <clefKeyDistance>1</clefKeyDistance>
    <clefTimesigDistance>1</clefTimesigDistance>
    <keyTimesigDistance>1</keyTimesigDistance>
    <keyBarlineDistance>1</keyBarlineDistance>
    <systemHeaderDistance>2.5</systemHeaderDistance>
    <systemHeaderTimeSigDistance>2</systemHeaderTimeSigDistance>
    <systemHeaderMinStartOfSystemDistance>1.25</systemHeaderMinStartOfSystemDistance>
    <systemTrailerRightMargin>0.5</systemTrailerRightMargin>
    <clefBarlineDistance>0.5</clefBarlineDistance>
    <timesigBarlineDistance>0.5</timesigBarlineDistance>
    <timeSigPlacement>normal</timeSigPlacement>
    <timeSigCenterOnBarline>1</timeSigCenterOnBarline>
    <timeSigVSMarginCentered>hangIntoMargin</timeSigVSMarginCentered>
    <timeSigVSMarginNonCentered>rightAlignToBarline</timeSigVSMarginNonCentered>
    <timeSigCenterAcrossStaveGroup>0</timeSigCenterAcrossStaveGroup>
    <timeSigNormalStyle>normal</timeSigNormalStyle>
    <timeSigNormalScale w="1" h="1"/>
    <timeSigNormalScaleLock>1</timeSigNormalScaleLock>
    <timeSigNormalNumDist>0</timeSigNormalNumDist>
    <timeSigNormalY>0</timeSigNormalY>
    <timeSigAboveStyle>normal</timeSigAboveStyle>
    <timeSigAboveScale w="2" h="2"/>
    <timeSigAboveScaleLock>1</timeSigAboveScaleLock>
    <timeSigAboveNumDist>0.1</timeSigAboveNumDist>
    <timeSigAboveY>-1</timeSigAboveY>
    <timeSigAcrossStyle>narrow</timeSigAcrossStyle>
    <timeSigAcrossScale w="4" h="4"/>
    <timeSigAcrossScaleLock>1</timeSigAcrossScaleLock>
    <timeSigAcrossNumDist>0.1</timeSigAcrossNumDist>
    <timeSigAcrossY>0</timeSigAcrossY>
    <useStraightNoteFlags>0</useStraightNoteFlags>
    <stemWidth>0.2</stemWidth>
    <shortenStem>1</shortenStem>
    <stemLength>3.5</stemLength>
    <stemLengthSmall>2.25</stemLengthSmall>
    <shortStemStartLocation>1</shortStemStartLocation>
    <shortestStem>2.25</shortestStem>
    <combineVoice>1</combineVoice>
    <beginRepeatLeftMargin>1</beginRepeatLeftMargin>
    <minNoteDistance>0.2</minNoteDistance>
    <barNoteDistance>1.3</barNoteDistance>
    <barAccidentalDistance>0.65</barAccidentalDistance>
    <noteBarDistance>1.5</noteBarDistance>
    <spacingDensity>1</spacingDensity>
    <measureSpacing>1.5</measureSpacing>
    <measureRepeatNumberPos>-0.5</measureRepeatNumberPos>
    <mrNumberSeries>0</mrNumberSeries>
    <mrNumberEveryXMeasures>4</mrNumberEveryXMeasures>
    <mrNumberSeriesWithParentheses>1</mrNumberSeriesWithParentheses>
    <oneMeasureRepeatShow1>0</oneMeasureRepeatShow1>
    <fourMeasureRepeatShowExtenders>0</fourMeasureRepeatShowExtenders>
    <staffLineWidth>0.1</staffLineWidth>
    <ledgerLineWidth>0.2</ledgerLineWidth>
    <ledgerLineLength>0.2</ledgerLineLength>
    <stemSlashPosition>2</stemSlashPosition>
    <stemSlashAngle>40</stemSlashAngle>
    <stemSlashThickness>0.125</stemSlashThickness>
    <accidentalDistance>0.22</accidentalDistance>
    <accidentalNoteDistance>0.25</accidentalNoteDistance>
    <bracketedAccidentalPadding>0.175</bracketedAccidentalPadding>
    <alignAccidentalsLeft>0</alignAccidentalsLeft>
    <accidentalOrderFollowsNoteDisplacement>0</accidentalOrderFollowsNoteDisplacement>
    <alignAccidentalOctavesAcrossSubChords>0</alignAccidentalOctavesAcrossSubChords>
    <keepAccidentalSecondsTogether>0</keepAccidentalSecondsTogether>
    <alignOffsetOctaveAccidentals>0</alignOffsetOctaveAccidentals>
    <keysigAccidentalDistance>0.3</keysigAccidentalDistance>
    <keysigNaturalDistance>0.4</keysigNaturalDistance>
    <beamWidth>0.5</beamWidth>
    <useWideBeams>0</useWideBeams>
    <beamMinLen>1.3</beamMinLen>
    <beamNoSlope>0</beamNoSlope>
    <snapCustomBeamsToGrid>1</snapCustomBeamsToGrid>
    <frenchStyleBeams>0</frenchStyleBeams>
    <dotMag>1</dotMag>
    <dotNoteDistance>0.5</dotNoteDistance>
    <dotRestDistance>0.25</dotRestDistance>
    <dotDotDistance>0.65</dotDotDistance>
    <propertyDistanceHead>0.4</propertyDistanceHead>
    <propertyDistanceStem>0.4</propertyDistanceStem>
    <propertyDistance>0.4</propertyDistance>
    <articulationMag>1</articulationMag>
    <articulationPosAbove x="0" y="0"/>
    <articulationAnchorDefault>2</articulationAnchorDefault>
    <articulationAnchorLuteFingering>1</articulationAnchorLuteFingering>
    <articulationAnchorOther>0</articulationAnchorOther>
    <articulationStemHAlign>2</articulationStemHAlign>
    <articulationKeepTogether>1</articulationKeepTogether>
    <trillAlwaysShowCueNote>0</trillAlwaysShowCueNote>
    <lastSystemFillLimit>0.25</lastSystemFillLimit>
    <hairpinPlacement>1</hairpinPlacement>
    <hairpinPosAbove x="0" y="-2"/>
    <hairpinPosBelow x="0" y="2"/>
    <hairpinLinePosAbove x="0" y="-3"/>
    <hairpinLinePosBelow x="0" y="4"/>
    <hairpinHeight>1.15</hairpinHeight>
    <hairpinContHeight>0.5</hairpinContHeight>
    <hairpinLineWidth>0.2</hairpinLineWidth>
    <hairpinFontFace>MuseJazz Text</hairpinFontFace>
    <hairpinFontSize>10</hairpinFontSize>
    <hairpinLineSpacing>1</hairpinLineSpacing>
    <hairpinFontSpatiumDependent>1</hairpinFontSpatiumDependent>
    <hairpinFontStyle>2</hairpinFontStyle>
    <hairpinColor r="0" g="0" b="0" a="255"/>
    <hairpinTextAlign>left,baseline</hairpinTextAlign>
    <hairpinFrameType>0</hairpinFrameType>
    <hairpinFramePadding>0.2</hairpinFramePadding>
    <hairpinFrameWidth>0.1</hairpinFrameWidth>
    <hairpinFrameRound>0</hairpinFrameRound>
    <hairpinFrameFgColor r="0" g="0" b="0" a="255"/>
    <hairpinFrameBgColor r="255" g="255" b="255" a="0"/>
    <hairpinPosition>left</hairpinPosition>
    <hairpinText></hairpinText>
    <hairpinCrescText>cresc.</hairpinCrescText>
    <hairpinDecrescText>dim.</hairpinDecrescText>
    <hairpinCrescContText>(cresc.)</hairpinCrescContText>
    <hairpinDecrescContText>(dim.)</hairpinDecrescContText>
    <hairpinLineStyle>solid</hairpinLineStyle>
    <hairpinDashLineLen>3</hairpinDashLineLen>
    <hairpinDashGapLen>3</hairpinDashGapLen>
    <hairpinLineLineStyle>dashed</hairpinLineLineStyle>
    <hairpinLineDashLineLen>6</hairpinLineDashLineLen>
    <hairpinLineDashGapLen>9</hairpinLineDashGapLen>
    <pedalPlacement>1</pedalPlacement>
    <pedalPosAbove x="0" y="-1"/>
    <pedalPosBelow x="0" y="2.5"/>
    <pedalLineWidth>0.2</pedalLineWidth>
    <pedalLineStyle>solid</pedalLineStyle>
    <pedalDashLineLen>4</pedalDashLineLen>
    <pedalDashGapLen>4</pedalDashGapLen>
    <pedalHookHeight>1.2</pedalHookHeight>
    <pedalFontFace>MuseJazz Text</pedalFontFace>
    <pedalFontSize>12</pedalFontSize>
    <pedalLineSpacing>1</pedalLineSpacing>
    <pedalFontSpatiumDependent>1</pedalFontSpatiumDependent>
    <pedalMusicalSymbolsScale>1</pedalMusicalSymbolsScale>
    <pedalFontStyle>0</pedalFontStyle>
    <pedalColor r="0" g="0" b="0" a="255"/>
    <pedalTextAlign>left,baseline</pedalTextAlign>
    <pedalFrameType>0</pedalFrameType>
    <pedalFramePadding>0.2</pedalFramePadding>
    <pedalFrameWidth>0.1</pedalFrameWidth>
    <pedalFrameRound>0</pedalFrameRound>
    <pedalFrameFgColor r="0" g="0" b="0" a="255"/>
    <pedalFrameBgColor r="255" g="255" b="255" a="0"/>
    <pedalPosition>left</pedalPosition>
    <pedalText>&lt;sym&gt;keyboardPedalPed&lt;/sym&gt;</pedalText>
    <pedalHookText></pedalHookText>
    <pedalContinueText>&lt;sym&gt;keyboardPedalParensLeft&lt;/sym&gt;&lt;sym&gt;keyboardPedalPed&lt;/sym&gt;&lt;sym&gt;keyboardPedalParensRight&lt;/sym&gt;</pedalContinueText>
    <pedalContinueHookText></pedalContinueHookText>
    <pedalEndText></pedalEndText>
    <pedalRosetteEndText>&lt;sym&gt;keyboardPedalUp&lt;/sym&gt;</pedalRosetteEndText>
    <trillPlacement>0</trillPlacement>
    <trillPosAbove x="0" y="-0.5"/>
    <trillPosBelow x="0" y="2"/>
    <vibratoPlacement>0</vibratoPlacement>
    <vibratoPosAbove x="0" y="-1"/>
    <vibratoPosBelow x="0" y="1"/>
    <harmonyFretDist>1</harmonyFretDist>
    <minHarmonyDistance>0.5</minHarmonyDistance>
    <harmonyHarmonyDistance>0.5</harmonyHarmonyDistance>
    <maxHarmonyBarDistance>3</maxHarmonyBarDistance>
    <maxChordShiftAbove>3</maxChordShiftAbove>
    <maxChordShiftBelow>3</maxChordShiftBelow>
    <harmonyPlacement>0</harmonyPlacement>
    <romanNumeralPlacement>1</romanNumeralPlacement>
    <nashvilleNumberPlacement>0</nashvilleNumberPlacement>
    <harmonyVoiceLiteral>1</harmonyVoiceLiteral>
    <harmonyVoicing>0</harmonyVoicing>
    <harmonyDuration>0</harmonyDuration>
    <chordSymbolAPosAbove x="0" y="-2.5"/>
    <chordSymbolAPosBelow x="0" y="3.5"/>
    <chordSymbolBPosAbove x="0" y="-5.5"/>
    <chordSymbolBPosBelow x="0" y="3.5"/>
    <romanNumeralPosAbove x="0" y="-2.5"/>
    <romanNumeralPosBelow x="0" y="3.5"/>
    <nashvilleNumberPosAbove x="0" y="-2.5"/>
    <nashvilleNumberPosBelow x="0" y="3.5"/>
    <chordSymbolAFontFace>MuseJazz Text</chordSymbolAFontFace>
    <chordSymbolAFontSize>15</chordSymbolAFontSize>
    <chordSymbolALineSpacing>1</chordSymbolALineSpacing>
    <chordSymbolAFontSpatiumDependent>1</chordSymbolAFontSpatiumDependent>
    <chordSymbolAFontStyle>0</chordSymbolAFontStyle>
    <chordSymbolAColor r="0" g="0" b="0" a="255"/>
    <chordSymbolAAlign>left,baseline</chordSymbolAAlign>
    <chordSymbolAFrameType>0</chordSymbolAFrameType>
    <chordSymbolAFramePadding>0.2</chordSymbolAFramePadding>
    <chordSymbolAFrameWidth>0.1</chordSymbolAFrameWidth>
    <chordSymbolAFrameRound>0</chordSymbolAFrameRound>
    <chordSymbolAFrameFgColor r="0" g="0" b="0" a="255"/>
    <chordSymbolAFrameBgColor r="255" g="255" b="255" a="0"/>
    <chordSymbolBFontFace>MuseJazz Text</chordSymbolBFontFace>
    <chordSymbolBFontSize>12</chordSymbolBFontSize>
    <chordSymbolBLineSpacing>1</chordSymbolBLineSpacing>
    <chordSymbolBFontSpatiumDependent>1</chordSymbolBFontSpatiumDependent>
    <chordSymbolBFontStyle>2</chordSymbolBFontStyle>
    <chordSymbolBColor r="0" g="0" b="0" a="255"/>
    <chordSymbolBAlign>left,baseline</chordSymbolBAlign>
    <chordSymbolBFrameType>0</chordSymbolBFrameType>
    <chordSymbolBFramePadding>0.2</chordSymbolBFramePadding>
    <chordSymbolBFrameWidth>0.1</chordSymbolBFrameWidth>
    <chordSymbolBFrameRound>0</chordSymbolBFrameRound>
    <chordSymbolBFrameFgColor r="0" g="0" b="0" a="255"/>
    <chordSymbolBFrameBgColor r="255" g="255" b="255" a="0"/>
    <romanNumeralFontFace>Campania</romanNumeralFontFace>
    <romanNumeralFontSize>12</romanNumeralFontSize>
    <romanNumeralLineSpacing>1</romanNumeralLineSpacing>
    <romanNumeralFontSpatiumDependent>1</romanNumeralFontSpatiumDependent>
    <romanNumeralFontStyle>0</romanNumeralFontStyle>
    <romanNumeralColor r="0" g="0" b="0" a="255"/>
    <romanNumeralAlign>left,baseline</romanNumeralAlign>
    <romanNumeralFrameType>0</romanNumeralFrameType>
    <romanNumeralFramePadding>0.2</romanNumeralFramePadding>
    <romanNumeralFrameWidth>0.1</romanNumeralFrameWidth>
    <romanNumeralFrameRound>0</romanNumeralFrameRound>
    <romanNumeralFrameFgColor r="0" g="0" b="0" a="255"/>
    <romanNumeralFrameBgColor r="255" g="255" b="255" a="0"/>
    <nashvilleNumberFontFace>Edwin</nashvilleNumberFontFace>
    <nashvilleNumberFontSize>12</nashvilleNumberFontSize>
    <nashvilleNumberLineSpacing>1</nashvilleNumberLineSpacing>
    <nashvilleNumberFontSpatiumDependent>1</nashvilleNumberFontSpatiumDependent>
    <nashvilleNumberFontStyle>0</nashvilleNumberFontStyle>
    <nashvilleNumberColor r="0" g="0" b="0" a="255"/>
    <nashvilleNumberAlign>left,baseline</nashvilleNumberAlign>
    <nashvilleNumberFrameType>0</nashvilleNumberFrameType>
    <nashvilleNumberFramePadding>0.2</nashvilleNumberFramePadding>
    <nashvilleNumberFrameWidth>0.1</nashvilleNumberFrameWidth>
    <nashvilleNumberFrameRound>0</nashvilleNumberFrameRound>
    <nashvilleNumberFrameFgColor r="0" g="0" b="0" a="255"/>
    <nashvilleNumberFrameBgColor r="255" g="255" b="255" a="0"/>
    <capoPosition>0</capoPosition>
    <fretNumMag>2</fretNumMag>
    <fretNumPos>0</fretNumPos>
    <fretY>1</fretY>
    <fretMinDistance>0.5</fretMinDistance>
    <fretMag>1</fretMag>
    <fretPlacement>0</fretPlacement>
    <fretStrings>6</fretStrings>
    <fretFrets>4</fretFrets>
    <fretNut>1</fretNut>
    <fretDotSize>1</fretDotSize>
    <fretDotSpatiumSize>0.5</fretDotSpatiumSize>
    <fretStringSpacing>0.7</fretStringSpacing>
    <fretFretSpacing>0.8</fretFretSpacing>
    <fretOrientation>0</fretOrientation>
    <maxFretShiftAbove>3</maxFretShiftAbove>
    <maxFretShiftBelow>3</maxFretShiftBelow>
    <fretNutThickness>0.3</fretNutThickness>
    <fretUseCustomSuffix>0</fretUseCustomSuffix>
    <fretCustomSuffix>fr</fretCustomSuffix>
    <barreAppearanceSlur>0</barreAppearanceSlur>
    <barreLineWidth>1</barreLineWidth>
    <fretShowFingerings>0</fretShowFingerings>
    <fretStyleExtended>0</fretStyleExtended>
    <showPageNumber>1</showPageNumber>
    <showPageNumberOne>0</showPageNumberOne>
    <pageNumberOddEven>1</pageNumberOddEven>
    <showMeasureNumber>0</showMeasureNumber>
    <showMeasureNumberOne>0</showMeasureNumberOne>
    <measureNumberInterval>5</measureNumberInterval>
    <measureNumberSystem>1</measureNumberSystem>
    <measureNumberPlacementMode>above-system</measureNumberPlacementMode>
    <smallNoteMag>0.7</smallNoteMag>
    <scaleRythmicSpacingForSmallNotes>0</scaleRythmicSpacingForSmallNotes>
    <graceNoteMag>0.7</graceNoteMag>
    <graceToMainNoteDist>0.45</graceToMainNoteDist>
    <graceToGraceNoteDist>0.3</graceToGraceNoteDist>
    <smallStaffMag>0.7</smallStaffMag>
    <smallClefMag>0.8</smallClefMag>
    <genClef>1</genClef>
    <hideTabClefAfterFirst>1</hideTabClefAfterFirst>
    <genKeysig>1</genKeysig>
    <genCourtesyTimesig>1</genCourtesyTimesig>
    <genCourtesyKeysig>1</genCourtesyKeysig>
    <genCourtesyClef>1</genCourtesyClef>
    <keySigCourtesyBarlineMode>2</keySigCourtesyBarlineMode>
    <timeSigCourtesyBarlineMode>0</timeSigCourtesyBarlineMode>
    <barlineBeforeSigChange>0</barlineBeforeSigChange>
    <doubleBarlineBeforeKeySig>0</doubleBarlineBeforeKeySig>
    <doubleBarlineBeforeTimeSig>0</doubleBarlineBeforeTimeSig>
    <swingRatio>60</swingRatio>
    <swingUnit></swingUnit>
    <chordSymbolSpelling>standard</chordSymbolSpelling>
    <automaticCapitalization>1</automaticCapitalization>
    <lowerCaseMinorChords>0</lowerCaseMinorChords>
    <lowerCaseBassNotes>0</lowerCaseBassNotes>
    <allCapsNoteNames>0</allCapsNoteNames>
    <chordStyle>jazz</chordStyle>
    <chordsXmlFile>0</chordsXmlFile>
    <chordDescriptionFile>chords_jazz.xml</chordDescriptionFile>
    <chordExtensionMag>1</chordExtensionMag>
    <chordExtensionAdjust>0</chordExtensionAdjust>
    <chordModifierMag>1</chordModifierMag>
    <chordModifierAdjust>0</chordModifierAdjust>
    <verticallyStackModifiers>0</verticallyStackModifiers>
    <chordStackedModifierMag>0.75</chordStackedModifierMag>
    <chordBassNoteStagger>0</chordBassNoteStagger>
    <chordBassNoteScale>1</chordBassNoteScale>
    <polychordDividerThickness>0.11</polychordDividerThickness>
    <polychordDividerSpacing>0.4</polychordDividerSpacing>
    <verticallyAlignChordSymbols>1</verticallyAlignChordSymbols>
    <chordSymPosition>left</chordSymPosition>
    <chordAlignmentToFretboard>center</chordAlignmentToFretboard>
    <chordAlignmentExcludeModifiers>0</chordAlignmentExcludeModifiers>
    <concertPitch>0</concertPitch>
    <multiVoiceRestTwoSpaceOffset>0</multiVoiceRestTwoSpaceOffset>
    <mergeMatchingRests>0</mergeMatchingRests>
    <createMultiMeasureRests>0</createMultiMeasureRests>
    <minEmptyMeasures>2</minEmptyMeasures>
    <singleMeasureMMRestUseNormalRest>1</singleMeasureMMRestUseNormalRest>
    <singleMeasureMMRestShowNumber>1</singleMeasureMMRestShowNumber>
    <minMMRestWidth>4</minMMRestWidth>
    <mmRestConstantWidth>0</mmRestConstantWidth>
    <mmRestReferenceWidth>2</mmRestReferenceWidth>
    <mmRestMaxWidthIncrease>8</mmRestMaxWidthIncrease>
    <mmRestNumberPos>-0.5</mmRestNumberPos>
    <mmRestBetweenStaves>1</mmRestBetweenStaves>
    <mmRestNumberMaskHBar>1</mmRestNumberMaskHBar>
    <multiMeasureRestMargin>1.2</multiMeasureRestMargin>
    <mmRestHBarThickness>0.7</mmRestHBarThickness>
    <mmRestHBarVStrokeThickness>0.2</mmRestHBarVStrokeThickness>
    <mmRestHBarVStrokeHeight>2</mmRestHBarVStrokeHeight>
    <oldStyleMultiMeasureRests>0</oldStyleMultiMeasureRests>
    <mmRestOldStyleMaxMeasures>9</mmRestOldStyleMaxMeasures>
    <mmRestOldStyleSpacing>0.85</mmRestOldStyleSpacing>
    <hideEmptyStaves>0</hideEmptyStaves>
    <dontHideStavesInFirstSystem>1</dontHideStavesInFirstSystem>
    <enableIndentationOnFirstSystem>0</enableIndentationOnFirstSystem>
    <firstSystemIndentationValue>5</firstSystemIndentationValue>
    <alwaysShowBracketsWhenEmptyStavesAreHidden>0</alwaysShowBracketsWhenEmptyStavesAreHidden>
    <alwaysShowSquareBracketsWhenEmptyStavesAreHidden>0</alwaysShowSquareBracketsWhenEmptyStavesAreHidden>
    <hideInstrumentNameIfOneInstrument>1</hideInstrumentNameIfOneInstrument>
    <firstSystemInstNameVisibility>0</firstSystemInstNameVisibility>
    <subsSystemInstNameVisibility>1</subsSystemInstNameVisibility>
    <gateTime>100</gateTime>
    <tenutoGateTime>100</tenutoGateTime>
    <staccatoGateTime>50</staccatoGateTime>
    <slurGateTime>100</slurGateTime>
    <arpeggioNoteDistance>0.5</arpeggioNoteDistance>
    <arpeggioAccidentalDistance>0.3</arpeggioAccidentalDistance>
    <arpeggioAccidentalDistanceMin>0.33</arpeggioAccidentalDistanceMin>
    <arpeggioLineWidth>0.18</arpeggioLineWidth>
    <arpeggioHookLen>0.8</arpeggioHookLen>
    <arpeggioHiddenInStdIfTab>0</arpeggioHiddenInStdIfTab>
    <slurEndWidth>0.12</slurEndWidth>
    <slurMidWidth>0.25</slurMidWidth>
    <slurDottedWidth>0.1</slurDottedWidth>
    <angleHangingSlursAwayFromStaff>0</angleHangingSlursAwayFromStaff>
    <tieEndWidth>0.12</tieEndWidth>
    <tieMidWidth>0.25</tieMidWidth>
    <tieDottedWidth>0.1</tieDottedWidth>
    <minTieLength>1</minTieLength>
    <minHangingTieLength>1.5</minHangingTieLength>
    <minStraightGlissandoLength>1.2</minStraightGlissandoLength>
    <minWigglyGlissandoLength>2</minWigglyGlissandoLength>
    <slurMinDistance>0.5</slurMinDistance>
    <tieMinDistance>0.5</tieMinDistance>
    <laissezVibMinDistance>0.5</laissezVibMinDistance>
    <headerToLineStartDistance>1</headerToLineStartDistance>
    <lineEndToBarlineDistance>0.25</lineEndToBarlineDistance>
    <barlineToLineStartDistance>0.65</barlineToLineStartDistance>
    <tiePlacementSingleNote>outside</tiePlacementSingleNote>
    <tiePlacementChord>inside</tiePlacementChord>
    <tieDotsPlacement>auto</tieDotsPlacement>
    <tieMinShoulderHeight>0.3</tieMinShoulderHeight>
    <tieMaxShoulderHeight>2</tieMaxShoulderHeight>
    <minLaissezVibLength>2</minLaissezVibLength>
    <laissezVibUseSmuflSym>0</laissezVibUseSmuflSym>
    <sectionPause>3</sectionPause>
    <musicalSymbolFont>MuseJazz</musicalSymbolFont>
    <musicalTextFont>MuseJazz Text</musicalTextFont>
    <showHeader>1</showHeader>
    <headerFirstPage>0</headerFirstPage>
    <headerOddEven>1</headerOddEven>
    <evenHeaderL>$p</evenHeaderL>
    <evenHeaderC></evenHeaderC>
    <evenHeaderR></evenHeaderR>
    <oddHeaderL></oddHeaderL>
    <oddHeaderC></oddHeaderC>
    <oddHeaderR>$p</oddHeaderR>
    <showFooter>1</showFooter>
    <footerFirstPage>1</footerFirstPage>
    <footerOddEven>1</footerOddEven>
    <evenFooterL></evenFooterL>
    <evenFooterC>$:copyright:</evenFooterC>
    <evenFooterR></evenFooterR>
    <oddFooterL></oddFooterL>
    <oddFooterC>$:copyright:</oddFooterC>
    <oddFooterR></oddFooterR>
    <voltaPosAbove x="-0.6" y="-5.6"/>
    <voltaHook>2.2</voltaHook>
    <voltaLineWidth>0.2</voltaLineWidth>
    <voltaLineStyle>solid</voltaLineStyle>
    <voltaDashLineLen>5</voltaDashLineLen>
    <voltaDashGapLen>5</voltaDashGapLen>
    <voltaFontFace>MuseJazz Text</voltaFontFace>
    <voltaFontSize>11</voltaFontSize>
    <voltaLineSpacing>1</voltaLineSpacing>
    <voltaFontSpatiumDependent>1</voltaFontSpatiumDependent>
    <voltaFontStyle>1</voltaFontStyle>
    <voltaColor r="0" g="0" b="0" a="255"/>
    <voltaAlign>left,baseline</voltaAlign>
    <voltaOffset x="0.6" y="2.2"/>
    <voltaFrameType>0</voltaFrameType>
    <voltaFramePadding>0.2</voltaFramePadding>
    <voltaFrameWidth>0.1</voltaFrameWidth>
    <voltaFrameRound>0</voltaFrameRound>
    <voltaFrameFgColor r="0" g="0" b="0" a="255"/>
    <voltaFrameBgColor r="255" g="255" b="255" a="0"/>
    <voltaPosition>left</voltaPosition>
    <voltaAlignStartBeforeKeySig>0</voltaAlignStartBeforeKeySig>
    <voltaAlignEndLeftOfBarline>0</voltaAlignEndLeftOfBarline>
    <ottava8VAPlacement>0</ottava8VAPlacement>
    <ottava8VBPlacement>1</ottava8VBPlacement>
    <ottava15MAPlacement>0</ottava15MAPlacement>
    <ottava15MBPlacement>1</ottava15MBPlacement>
    <ottava22MAPlacement>0</ottava22MAPlacement>
    <ottava22MBPlacement>1</ottava22MBPlacement>
    <ottava8VAText>&lt;sym&gt;ottavaAlta&lt;/sym&gt;</ottava8VAText>
    <ottava8VAContinueText>&lt;sym&gt;ottavaAlta&lt;/sym&gt;</ottava8VAContinueText>
    <ottava8VBText>&lt;sym&gt;ottavaBassa&lt;/sym&gt;</ottava8VBText>
    <ottava8VBContinueText>&lt;sym&gt;ottavaBassa&lt;/sym&gt;</ottava8VBContinueText>
    <ottava15MAText>&lt;sym&gt;quindicesimaAlta&lt;/sym&gt;</ottava15MAText>
    <ottava15MAContinueText>&lt;sym&gt;quindicesimaAlta&lt;/sym&gt;</ottava15MAContinueText>
    <ottava15MBText>&lt;sym&gt;quindicesimaBassa&lt;/sym&gt;</ottava15MBText>
    <ottava15MBContinueText>&lt;sym&gt;quindicesimaBassa&lt;/sym&gt;</ottava15MBContinueText>
    <ottava22MAText>&lt;sym&gt;ventiduesimaAlta&lt;/sym&gt;</ottava22MAText>
    <ottava22MAContinueText>&lt;sym&gt;ventiduesimaAlta&lt;/sym&gt;</ottava22MAContinueText>
    <ottava22MBText>&lt;sym&gt;ventiduesimaBassa&lt;/sym&gt;</ottava22MBText>
    <ottava22MBContinueText>&lt;sym&gt;ventiduesimaBassa&lt;/sym&gt;</ottava22MBContinueText>
    <ottava8VAnoText>&lt;sym&gt;ottava&lt;/sym&gt;</ottava8VAnoText>
    <ottava8VAnoContinueText>&lt;sym&gt;ottava&lt;/sym&gt;</ottava8VAnoContinueText>
    <ottava8VBnoText>&lt;sym&gt;ottava&lt;/sym&gt;</ottava8VBnoText>
    <ottava8VBnoContinueText>&lt;sym&gt;ottava&lt;/sym&gt;</ottava8VBnoContinueText>
    <ottava15MAnoText>&lt;sym&gt;quindicesima&lt;/sym&gt;</ottava15MAnoText>
    <ottava15MAnoContinueText>&lt;sym&gt;quindicesima&lt;/sym&gt;</ottava15MAnoContinueText>
    <ottava15MBnoText>&lt;sym&gt;quindicesima&lt;/sym&gt;</ottava15MBnoText>
    <ottava15MBnoContinueText>&lt;sym&gt;quindicesima&lt;/sym&gt;</ottava15MBnoContinueText>
    <ottava22MAnoText>&lt;sym&gt;ventiduesima&lt;/sym&gt;</ottava22MAnoText>
    <ottava22MAnoContinueText>&lt;sym&gt;ventiduesima&lt;/sym&gt;</ottava22MAnoContinueText>
    <ottava22MBnoText>&lt;sym&gt;ventiduesima&lt;/sym&gt;</ottava22MBnoText>
    <ottava22MBnoContinueText>&lt;sym&gt;ventiduesima&lt;/sym&gt;</ottava22MBnoContinueText>
    <ottavaPosAbove x="0" y="-2"/>
    <ottavaPosBelow x="0" y="2"/>
    <ottavaHookAbove>1</ottavaHookAbove>
    <ottavaHookBelow>1</ottavaHookBelow>
    <ottavaLineWidth>0.2</ottavaLineWidth>
    <ottavaLineStyle>dashed</ottavaLineStyle>
    <ottavaDashLineLen>6</ottavaDashLineLen>
    <ottavaDashGapLen>6</ottavaDashGapLen>
    <ottavaNumbersOnly>1</ottavaNumbersOnly>
    <ottavaFontFace>MuseJazz Text</ottavaFontFace>
    <ottavaFontSize>10</ottavaFontSize>
    <ottavaLineSpacing>1</ottavaLineSpacing>
    <ottavaFontSpatiumDependent>1</ottavaFontSpatiumDependent>
    <ottavaMusicalSymbolsScale>1</ottavaMusicalSymbolsScale>
    <ottavaFontStyle>0</ottavaFontStyle>
    <ottavaColor r="0" g="0" b="0" a="255"/>
    <ottavaTextAlignAbove>left,top</ottavaTextAlignAbove>
    <ottavaTextAlignBelow>left,baseline</ottavaTextAlignBelow>
    <ottavaFrameType>0</ottavaFrameType>
    <ottavaFramePadding>0.2</ottavaFramePadding>
    <ottavaFrameWidth>0.1</ottavaFrameWidth>
    <ottavaFrameRound>0</ottavaFrameRound>
    <ottavaFrameFgColor r="0" g="0" b="0" a="255"/>
    <ottavaFrameBgColor r="255" g="255" b="255" a="0"/>
    <ottavaPosition>left</ottavaPosition>
    <tabClef>31</tabClef>
    <tremoloWidth>1.2</tremoloWidth>
    <tremoloBoxHeight>0.65</tremoloBoxHeight>
    <tremoloLineWidth>0.5</tremoloLineWidth>
    <tremoloDistance>0.8</tremoloDistance>
    <tremoloStyle>0</tremoloStyle>
    <tremoloStrokeLengthMultiplier>0.62</tremoloStrokeLengthMultiplier>
    <tremoloNoteSidePadding>1.25</tremoloNoteSidePadding>
    <tremoloOutSidePadding>0.5</tremoloOutSidePadding>
    <linearStretch>1.5</linearStretch>
    <crossMeasureValues>0</crossMeasureValues>
    <keySigNaturals>0</keySigNaturals>
    <tupletMaxSlope>0.5</tupletMaxSlope>
    <tupletOutOfStaff>1</tupletOutOfStaff>
    <tupletVHeadDistance>0.5</tupletVHeadDistance>
    <tupletVStemDistance>0.5</tupletVStemDistance>
    <tupletStemLeftDistance>0</tupletStemLeftDistance>
    <tupletStemRightDistance>0.5</tupletStemRightDistance>
    <tupletNoteLeftDistance>-0.5</tupletNoteLeftDistance>
    <tupletNoteRightDistance>0</tupletNoteRightDistance>
    <tupletBracketWidth>0.2</tupletBracketWidth>
    <tupletDirection>0</tupletDirection>
    <tupletNumberType>0</tupletNumberType>
    <tupletBracketType>0</tupletBracketType>
    <tupletFontFace>MuseJazz Text</tupletFontFace>
    <tupletFontSize>9</tupletFontSize>
    <tupletLineSpacing>1</tupletLineSpacing>
    <tupletFontSpatiumDependent>1</tupletFontSpatiumDependent>
    <tupletMusicalSymbolsScale>1</tupletMusicalSymbolsScale>
    <tupletFontStyle>2</tupletFontStyle>
    <tupletColor r="0" g="0" b="0" a="255"/>
    <tupletAlign>center,center</tupletAlign>
    <tupletUseSymbols>0</tupletUseSymbols>
    <tupletBracketHookHeight>0.75</tupletBracketHookHeight>
    <tupletOffset x="0" y="0"/>
    <tupletFrameType>0</tupletFrameType>
    <tupletFramePadding>0.2</tupletFramePadding>
    <tupletFrameWidth>0.1</tupletFrameWidth>
    <tupletFrameRound>0</tupletFrameRound>
    <tupletFrameFgColor r="0" g="0" b="0" a="255"/>
    <tupletFrameBgColor r="255" g="255" b="255" a="0"/>
    <tupletPosition>center</tupletPosition>
    <tupletExtendToEndOfDuration>0</tupletExtendToEndOfDuration>
    <tupletNumberRythmicCenter>0</tupletNumberRythmicCenter>
    <scaleBarlines>1</scaleBarlines>
    <barGraceDistance>1</barGraceDistance>
    <minVerticalDistance>0.5</minVerticalDistance>
    <skylineMinHorizontalClearance>0.25</skylineMinHorizontalClearance>
    <ornamentStyle>0</ornamentStyle>
    <autoplaceHairpinDynamicsDistance>0.5</autoplaceHairpinDynamicsDistance>
    <dynamicsHairpinVoiceBasedPlacement>0</dynamicsHairpinVoiceBasedPlacement>
    <dynamicsHairpinsAutoCenterOnGrandStaff>1</dynamicsHairpinsAutoCenterOnGrandStaff>
    <dynamicsHairpinsAboveForVocalStaves>1</dynamicsHairpinsAboveForVocalStaves>
    <dynamicsOverrideFont>0</dynamicsOverrideFont>
    <dynamicsFont>Leland</dynamicsFont>
    <dynamicsSize>1</dynamicsSize>
    <dynamicsPlacement>1</dynamicsPlacement>
    <dynamicsPosAbove x="0" y="-1.5"/>
    <dynamicsPosBelow x="0" y="2.5"/>
    <avoidBarLines>1</avoidBarLines>
    <snapToDynamics>1</snapToDynamics>
    <centerOnNotehead>1</centerOnNotehead>
    <dynamicsMinDistance>0.5</dynamicsMinDistance>
    <autoplaceVerticalAlignRange>2</autoplaceVerticalAlignRange>
    <textLinePlacement>0</textLinePlacement>
    <textLinePosAbove x="0" y="-1"/>
    <textLinePosBelow x="0" y="1"/>
    <textLineLineWidth>0.15</textLineLineWidth>
    <textLineLineStyle>solid</textLineLineStyle>
    <textLineDashLineLen>4</textLineDashLineLen>
    <textLineDashGapLen>4</textLineDashGapLen>
    <textLineHookHeight>1.5</textLineHookHeight>
    <textLineFrameType>0</textLineFrameType>
    <textLineFramePadding>0.2</textLineFramePadding>
    <textLineFrameWidth>0.1</textLineFrameWidth>
    <textLineFrameRound>0</textLineFrameRound>
    <textLineFrameFgColor r="0" g="0" b="0" a="255"/>
    <textLineFrameBgColor r="255" g="255" b="255" a="0"/>
    <textLinePosition>left</textLinePosition>
    <systemTextLinePlacement>0</systemTextLinePlacement>
    <systemTextLinePosAbove x="0" y="-1"/>
    <systemTextLinePosBelow x="0" y="1"/>
    <systemTextLineLineWidth>0.15</systemTextLineLineWidth>
    <systemTextLineLineStyle>solid</systemTextLineLineStyle>
    <systemTextLineDashLineLen>4</systemTextLineDashLineLen>
    <systemTextLineDashGapLen>4</systemTextLineDashGapLen>
    <systemTextLineHookHeight>1.5</systemTextLineHookHeight>
    <systemTextLineFrameType>0</systemTextLineFrameType>
    <systemTextLineFramePadding>0.2</systemTextLineFramePadding>
    <systemTextLineFrameWidth>0.1</systemTextLineFrameWidth>
    <systemTextLineFrameRound>0</systemTextLineFrameRound>
    <systemTextLineFrameFgColor r="0" g="0" b="0" a="255"/>
    <systemTextLineFrameBgColor r="255" g="255" b="255" a="0"/>
    <systemTextLinePosition>left</systemTextLinePosition>
    <tremoloBarLineWidth>0.12</tremoloBarLineWidth>
    <jumpPosAbove x="0" y="-2"/>
    <markerPosAbove x="0" y="-2"/>
    <defaultFontFace>MuseJazz Text</defaultFontFace>
    <defaultFontSize>10</defaultFontSize>
    <defaultLineSpacing>1</defaultLineSpacing>
    <defaultFontSpatiumDependent>1</defaultFontSpatiumDependent>
    <defaultFontStyle>0</defaultFontStyle>
    <defaultColor r="0" g="0" b="0" a="255"/>
    <defaultAlign>left,top</defaultAlign>
    <defaultFrameType>0</defaultFrameType>
    <defaultFramePadding>0.2</defaultFramePadding>
    <defaultFrameWidth>0.1</defaultFrameWidth>
    <defaultFrameRound>0</defaultFrameRound>
    <defaultFrameFgColor r="0" g="0" b="0" a="255"/>
    <defaultFrameBgColor r="255" g="255" b="255" a="0"/>
    <defaultOffset x="0" y="0"/>
    <defaultOffsetType>1</defaultOffsetType>
    <defaultSystemFlag>0</defaultSystemFlag>
    <defaultText></defaultText>
    <defaultPosition>left</defaultPosition>
    <titleFontFace>MuseJazz Text</titleFontFace>
    <titleFontSize>28</titleFontSize>
    <titleLineSpacing>1</titleLineSpacing>
    <titleFontSpatiumDependent>0</titleFontSpatiumDependent>
    <titleFontStyle>0</titleFontStyle>
    <titleColor r="0" g="0" b="0" a="255"/>
    <titleAlign>center,top</titleAlign>
    <titleOffset x="0" y="0"/>
    <titleOffsetType>0</titleOffsetType>
    <titleFrameType>0</titleFrameType>
    <titleFramePadding>0.2</titleFramePadding>
    <titleFrameWidth>0.1</titleFrameWidth>
    <titleFrameRound>0</titleFrameRound>
    <titleFrameFgColor r="0" g="0" b="0" a="255"/>
    <titleFrameBgColor r="255" g="255" b="255" a="0"/>
    <titlePosition>center</titlePosition>
    <subTitleFontFace>MuseJazz Text</subTitleFontFace>
    <subTitleFontSize>16</subTitleFontSize>
    <subTitleLineSpacing>1</subTitleLineSpacing>
    <subTitleFontSpatiumDependent>0</subTitleFontSpatiumDependent>
    <subTitleFontStyle>0</subTitleFontStyle>
    <subTitleColor r="0" g="0" b="0" a="255"/>
    <subTitleAlign>center,top</subTitleAlign>
    <subTitleOffset x="0" y="10"/>
    <subTitleOffsetType>0</subTitleOffsetType>
    <subTitleFrameType>0</subTitleFrameType>
    <subTitleFramePadding>0.2</subTitleFramePadding>
    <subTitleFrameWidth>0.1</subTitleFrameWidth>
    <subTitleFrameRound>0</subTitleFrameRound>
    <subTitleFrameFgColor r="0" g="0" b="0" a="255"/>
    <subTitleFrameBgColor r="255" g="255" b="255" a="0"/>
    <subTitlePosition>center</subTitlePosition>
    <composerFontFace>MuseJazz Text</composerFontFace>
    <composerFontSize>10</composerFontSize>
    <composerLineSpacing>1</composerLineSpacing>
    <composerFontSpatiumDependent>0</composerFontSpatiumDependent>
    <composerFontStyle>0</composerFontStyle>
    <composerColor r="0" g="0" b="0" a="255"/>
    <composerAlign>right,bottom</composerAlign>
    <composerOffset x="0" y="0"/>
    <composerOffsetType>0</composerOffsetType>
    <composerFrameType>0</composerFrameType>
    <composerFramePadding>0.2</composerFramePadding>
    <composerFrameWidth>0.1</composerFrameWidth>
    <composerFrameRound>0</composerFrameRound>
    <composerFrameFgColor r="0" g="0" b="0" a="255"/>
    <composerFrameBgColor r="255" g="255" b="255" a="0"/>
    <composerPosition>right</composerPosition>
    <lyricistFontFace>MuseJazz Text</lyricistFontFace>
    <lyricistFontSize>10</lyricistFontSize>
    <lyricistLineSpacing>1</lyricistLineSpacing>
    <lyricistFontSpatiumDependent>0</lyricistFontSpatiumDependent>
    <lyricistFontStyle>0</lyricistFontStyle>
    <lyricistColor r="0" g="0" b="0" a="255"/>
    <lyricistAlign>left,bottom</lyricistAlign>
    <lyricistOffset x="0" y="0"/>
    <lyricistOffsetType>0</lyricistOffsetType>
    <lyricistFrameType>0</lyricistFrameType>
    <lyricistFramePadding>0.2</lyricistFramePadding>
    <lyricistFrameWidth>0.1</lyricistFrameWidth>
    <lyricistFrameRound>0</lyricistFrameRound>
    <lyricistFrameFgColor r="0" g="0" b="0" a="255"/>
    <lyricistFrameBgColor r="255" g="255" b="255" a="0"/>
    <lyricistPosition>left</lyricistPosition>
    <fingeringFontFace>MuseJazz Text</fingeringFontFace>
    <fingeringFontSize>8</fingeringFontSize>
    <fingeringLineSpacing>1</fingeringLineSpacing>
    <fingeringFontSpatiumDependent>1</fingeringFontSpatiumDependent>
    <fingeringFontStyle>0</fingeringFontStyle>
    <fingeringColor r="0" g="0" b="0" a="255"/>
    <fingeringAlign>center,center</fingeringAlign>
    <fingeringFrameType>0</fingeringFrameType>
    <fingeringFramePadding>0.2</fingeringFramePadding>
    <fingeringFrameWidth>0.1</fingeringFrameWidth>
    <fingeringFrameRound>0</fingeringFrameRound>
    <fingeringFrameFgColor r="0" g="0" b="0" a="255"/>
    <fingeringFrameBgColor r="255" g="255" b="255" a="0"/>
    <fingeringOffset x="0" y="0"/>
    <fingeringPosition>center</fingeringPosition>
    <tabFretNumberFontFace>FreeSans</tabFretNumberFontFace>
    <tabFretNumberFontSize>9</tabFretNumberFontSize>
    <tabFretNumberLineSpacing>1</tabFretNumberLineSpacing>
    <tabFretNumberFontSpatiumDependent>1</tabFretNumberFontSpatiumDependent>
    <tabFretNumberFontStyle>0</tabFretNumberFontStyle>
    <tabFretNumberColor r="0" g="0" b="0" a="255"/>
    <tabFretNumberAlign>left,baseline</tabFretNumberAlign>
    <tabFretNumberOffset x="0" y="0"/>
    <tabFretNumberFrameType>0</tabFretNumberFrameType>
    <tabFretNumberFramePadding>0.2</tabFretNumberFramePadding>
    <tabFretNumberFrameWidth>0.1</tabFretNumberFrameWidth>
    <tabFretNumberFrameRound>0</tabFretNumberFrameRound>
    <tabFretNumberFrameFgColor r="0" g="0" b="0" a="255"/>
    <tabFretNumberFrameBgColor r="255" g="255" b="255" a="0"/>
    <lhGuitarFingeringFontFace>MuseJazz Text</lhGuitarFingeringFontFace>
    <lhGuitarFingeringFontSize>8</lhGuitarFingeringFontSize>
    <lhGuitarFingeringLineSpacing>1</lhGuitarFingeringLineSpacing>
    <lhGuitarFingeringFontSpatiumDependent>1</lhGuitarFingeringFontSpatiumDependent>
    <lhGuitarFingeringFontStyle>0</lhGuitarFingeringFontStyle>
    <lhGuitarFingeringColor r="0" g="0" b="0" a="255"/>
    <lhGuitarFingeringAlign>right,center</lhGuitarFingeringAlign>
    <lhGuitarFingeringFrameType>0</lhGuitarFingeringFrameType>
    <lhGuitarFingeringFramePadding>0.2</lhGuitarFingeringFramePadding>
    <lhGuitarFingeringFrameWidth>0.1</lhGuitarFingeringFrameWidth>
    <lhGuitarFingeringFrameRound>0</lhGuitarFingeringFrameRound>
    <lhGuitarFingeringFrameFgColor r="0" g="0" b="0" a="255"/>
    <lhGuitarFingeringFrameBgColor r="255" g="255" b="255" a="0"/>
    <lhGuitarFingeringOffset x="-0.5" y="0"/>
    <lhGuitarFingeringPosition>right</lhGuitarFingeringPosition>
    <rhGuitarFingeringFontFace>MuseJazz Text</rhGuitarFingeringFontFace>
    <rhGuitarFingeringFontSize>8</rhGuitarFingeringFontSize>
    <rhGuitarFingeringLineSpacing>1</rhGuitarFingeringLineSpacing>
    <rhGuitarFingeringFontSpatiumDependent>1</rhGuitarFingeringFontSpatiumDependent>
    <rhGuitarFingeringFontStyle>2</rhGuitarFingeringFontStyle>
    <rhGuitarFingeringColor r="0" g="0" b="0" a="255"/>
    <rhGuitarFingeringAlign>center,center</rhGuitarFingeringAlign>
    <rhGuitarFingeringFrameType>0</rhGuitarFingeringFrameType>
    <rhGuitarFingeringFramePadding>0.2</rhGuitarFingeringFramePadding>
    <rhGuitarFingeringFrameWidth>0.1</rhGuitarFingeringFrameWidth>
    <rhGuitarFingeringFrameRound>0</rhGuitarFingeringFrameRound>
    <rhGuitarFingeringFrameFgColor r="0" g="0" b="0" a="255"/>
    <rhGuitarFingeringFrameBgColor r="255" g="255" b="255" a="0"/>
    <rhGuitarFingeringOffset x="0" y="0"/>
    <rhGuitarFingeringPosition>center</rhGuitarFingeringPosition>
    <hammerOnPullOffTappingFontFace>Edwin</hammerOnPullOffTappingFontFace>
    <hammerOnPullOffTappingFontSize>8</hammerOnPullOffTappingFontSize>
    <hammerOnPullOffTappingLineSpacing>1</hammerOnPullOffTappingLineSpacing>
    <hammerOnPullOffTappingFontSpatiumDependent>1</hammerOnPullOffTappingFontSpatiumDependent>
    <hammerOnPullOffTappingFontStyle>0</hammerOnPullOffTappingFontStyle>
    <hammerOnPullOffTappingColor r="0" g="0" b="0" a="255"/>
    <hammerOnPullOffTappingAlign>left,baseline</hammerOnPullOffTappingAlign>
    <hammerOnPullOffTappingFrameType>0</hammerOnPullOffTappingFrameType>
    <hammerOnPullOffTappingFramePadding>0.2</hammerOnPullOffTappingFramePadding>
    <hammerOnPullOffTappingFrameWidth>0.1</hammerOnPullOffTappingFrameWidth>
    <hammerOnPullOffTappingFrameRound>0</hammerOnPullOffTappingFrameRound>
    <hammerOnPullOffTappingFrameFgColor r="0" g="0" b="0" a="255"/>
    <hammerOnPullOffTappingFrameBgColor r="255" g="255" b="255" a="0"/>
    <hammerOnPullOffTappingOffset x="0" y="0"/>
    <hammerOnPullOffTappingPosition>left</hammerOnPullOffTappingPosition>
    <hopoShowOnStandardStaves>1</hopoShowOnStandardStaves>
    <hopoShowOnTabStaves>1</hopoShowOnTabStaves>
    <hopoUpperCase>1</hopoUpperCase>
    <hopoShowAll>1</hopoShowAll>
    <hopoAlignLettersStandardStaves>1</hopoAlignLettersStandardStaves>
    <hopoAlignLettersTabStaves>1</hopoAlignLettersTabStaves>
    <lhTappingSymbolNormalStave>dot</lhTappingSymbolNormalStave>
    <lhTappingSymbolTab>dot</lhTappingSymbolTab>
    <lhTappingShowItemsNormalStave>0</lhTappingShowItemsNormalStave>
    <lhTappingShowItemsTab>0</lhTappingShowItemsTab>
    <lhTappingSlurTopAndBottomNoteOnTab>1</lhTappingSlurTopAndBottomNoteOnTab>
    <rhTappingSymbolNormalStave>plus</rhTappingSymbolNormalStave>
    <rhTappingSymbolTab>T</rhTappingSymbolTab>
    <stringNumberFontFace>MuseJazz Text</stringNumberFontFace>
    <stringNumberFontSize>8</stringNumberFontSize>
    <stringNumberLineSpacing>1</stringNumberLineSpacing>
    <stringNumberFontSpatiumDependent>1</stringNumberFontSpatiumDependent>
    <stringNumberFontStyle>0</stringNumberFontStyle>
    <stringNumberColor r="0" g="0" b="0" a="255"/>
    <stringNumberAlign>center,center</stringNumberAlign>
    <stringNumberFrameType>2</stringNumberFrameType>
    <stringNumberFramePadding>0.2</stringNumberFramePadding>
    <stringNumberFrameWidth>0.1</stringNumberFrameWidth>
    <stringNumberFrameRound>0</stringNumberFrameRound>
    <stringNumberFrameFgColor r="0" g="0" b="0" a="255"/>
    <stringNumberFrameBgColor r="255" g="255" b="255" a="0"/>
    <stringNumberOffset x="0" y="0"/>
    <stringNumberPosition>center</stringNumberPosition>
    <preferSameStringForTranspose>0</preferSameStringForTranspose>
    <stringTuningsFontSize>9</stringTuningsFontSize>
    <harpPedalDiagramFontFace>Edwin</harpPedalDiagramFontFace>
    <harpPedalDiagramFontSize>10</harpPedalDiagramFontSize>
    <harpPedalDiagramLineSpacing>1</harpPedalDiagramLineSpacing>
    <harpPedalDiagramFontSpatiumDependent>1</harpPedalDiagramFontSpatiumDependent>
    <harpPedalDiagramMusicalSymbolsScale>1</harpPedalDiagramMusicalSymbolsScale>
    <harpPedalDiagramFontStyle>0</harpPedalDiagramFontStyle>
    <harpPedalDiagramColor r="0" g="0" b="0" a="255"/>
    <harpPedalDiagramAlign>center,center</harpPedalDiagramAlign>
    <harpPedalDiagramFrameType>0</harpPedalDiagramFrameType>
    <harpPedalDiagramFramePadding>0.2</harpPedalDiagramFramePadding>
    <harpPedalDiagramFrameWidth>0.1</harpPedalDiagramFrameWidth>
    <harpPedalDiagramFrameRound>0</harpPedalDiagramFrameRound>
    <harpPedalDiagramFrameFgColor r="0" g="0" b="0" a="255"/>
    <harpPedalDiagramFrameBgColor r="255" g="255" b="255" a="0"/>
    <harpPedalDiagramOffset x="0" y="0"/>
    <harpPedalDiagramPlacement>0</harpPedalDiagramPlacement>
    <harpPedalDiagramPosAbove x="0" y="-1"/>
    <harpPedalDiagramPosBelow x="0" y="2.5"/>
    <harpPedalDiagramMinDistance>0.5</harpPedalDiagramMinDistance>
    <harpPedalDiagramPosition>center</harpPedalDiagramPosition>
    <harpPedalTextDiagramFontFace>Edwin</harpPedalTextDiagramFontFace>
    <harpPedalTextDiagramFontSize>8</harpPedalTextDiagramFontSize>
    <harpPedalTextDiagramLineSpacing>1</harpPedalTextDiagramLineSpacing>
    <harpPedalTextDiagramFontSpatiumDependent>1</harpPedalTextDiagramFontSpatiumDependent>
    <harpPedalTextDiagramFontStyle>0</harpPedalTextDiagramFontStyle>
    <harpPedalTextDiagramColor r="0" g="0" b="0" a="255"/>
    <harpPedalTextDiagramAlign>left,baseline</harpPedalTextDiagramAlign>
    <harpPedalTextDiagramFrameType>0</harpPedalTextDiagramFrameType>
    <harpPedalTextDiagramFramePadding>0.2</harpPedalTextDiagramFramePadding>
    <harpPedalTextDiagramFrameWidth>0.1</harpPedalTextDiagramFrameWidth>
    <harpPedalTextDiagramFrameRound>0</harpPedalTextDiagramFrameRound>
    <harpPedalTextDiagramFrameFgColor r="0" g="0" b="0" a="255"/>
    <harpPedalTextDiagramFrameBgColor r="255" g="255" b="255" a="0"/>
    <harpPedalTextDiagramOffset x="0" y="0"/>
    <harpPedalTextDiagramPlacement>1</harpPedalTextDiagramPlacement>
    <harpPedalTextDiagramPosAbove x="0" y="-1.5"/>
    <harpPedalTextDiagramPosBelow x="0" y="2.5"/>
    <harpPedalTextDiagramMinDistance>0.5</harpPedalTextDiagramMinDistance>
    <harpPedalTextDiagramPosition>left</harpPedalTextDiagramPosition>
    <articulationFontFace>Edwin</articulationFontFace>
    <articulationFontSize>8</articulationFontSize>
    <articulationLineSpacing>1</articulationLineSpacing>
    <articulationFontSpatiumDependent>1</articulationFontSpatiumDependent>
    <articulationFontStyle>0</articulationFontStyle>
    <articulationColor r="0" g="0" b="0" a="255"/>
    <articulationAlign>left,baseline</articulationAlign>
    <articulationFrameType>0</articulationFrameType>
    <articulationFramePadding>0.2</articulationFramePadding>
    <articulationFrameWidth>0.1</articulationFrameWidth>
    <articulationFrameRound>0</articulationFrameRound>
    <articulationFrameFgColor r="0" g="0" b="0" a="255"/>
    <articulationFrameBgColor r="255" g="255" b="255" a="0"/>
    <articulationOffset x="0" y="0"/>
    <articulationPosition>left</articulationPosition>
    <longInstrumentFontFace>MuseJazz Text</longInstrumentFontFace>
    <longInstrumentFontSize>10</longInstrumentFontSize>
    <longInstrumentLineSpacing>1</longInstrumentLineSpacing>
    <longInstrumentFontSpatiumDependent>1</longInstrumentFontSpatiumDependent>
    <longInstrumentFontStyle>0</longInstrumentFontStyle>
    <longInstrumentColor r="0" g="0" b="0" a="255"/>
    <longInstrumentAlign>right,center</longInstrumentAlign>
    <longInstrumentOffset x="0" y="0"/>
    <longInstrumentFrameType>0</longInstrumentFrameType>
    <longInstrumentFramePadding>0.2</longInstrumentFramePadding>
    <longInstrumentFrameWidth>0.1</longInstrumentFrameWidth>
    <longInstrumentFrameRound>0</longInstrumentFrameRound>
    <longInstrumentFrameFgColor r="0" g="0" b="0" a="255"/>
    <longInstrumentFrameBgColor r="255" g="255" b="255" a="0"/>
    <longInstrumentPosition>right</longInstrumentPosition>
    <shortInstrumentFontFace>MuseJazz Text</shortInstrumentFontFace>
    <shortInstrumentFontSize>10</shortInstrumentFontSize>
    <shortInstrumentLineSpacing>1</shortInstrumentLineSpacing>
    <shortInstrumentFontSpatiumDependent>1</shortInstrumentFontSpatiumDependent>
    <shortInstrumentFontStyle>0</shortInstrumentFontStyle>
    <shortInstrumentColor r="0" g="0" b="0" a="255"/>
    <shortInstrumentAlign>right,center</shortInstrumentAlign>
    <shortInstrumentOffset x="0" y="0"/>
    <shortInstrumentFrameType>0</shortInstrumentFrameType>
    <shortInstrumentFramePadding>0.2</shortInstrumentFramePadding>
    <shortInstrumentFrameWidth>0.1</shortInstrumentFrameWidth>
    <shortInstrumentFrameRound>0</shortInstrumentFrameRound>
    <shortInstrumentFrameFgColor r="0" g="0" b="0" a="255"/>
    <shortInstrumentFrameBgColor r="255" g="255" b="255" a="0"/>
    <shortInstrumentPosition>right</shortInstrumentPosition>
    <partInstrumentFontFace>MuseJazz Text</partInstrumentFontFace>
    <partInstrumentFontSize>14</partInstrumentFontSize>
    <partInstrumentLineSpacing>1</partInstrumentLineSpacing>
    <partInstrumentFontSpatiumDependent>0</partInstrumentFontSpatiumDependent>
    <partInstrumentFontStyle>0</partInstrumentFontStyle>
    <partInstrumentColor r="0" g="0" b="0" a="255"/>
    <partInstrumentAlign>left,top</partInstrumentAlign>
    <partInstrumentOffset x="0" y="0"/>
    <partInstrumentFrameType>0</partInstrumentFrameType>
    <partInstrumentFramePadding>0.2</partInstrumentFramePadding>
    <partInstrumentFrameWidth>0.1</partInstrumentFrameWidth>
    <partInstrumentFrameRound>0</partInstrumentFrameRound>
    <partInstrumentFrameFgColor r="0" g="0" b="0" a="255"/>
    <partInstrumentFrameBgColor r="255" g="255" b="255" a="0"/>
    <partInstrumentPosition>left</partInstrumentPosition>
    <dynamicsFontFace>MuseJazz Text</dynamicsFontFace>
    <dynamicsFontSize>10</dynamicsFontSize>
    <dynamicsLineSpacing>1</dynamicsLineSpacing>
    <dynamicsFontSpatiumDependent>1</dynamicsFontSpatiumDependent>
    <dynamicsFontStyle>2</dynamicsFontStyle>
    <dynamicsColor r="0" g="0" b="0" a="255"/>
    <dynamicsAlign>center,baseline</dynamicsAlign>
    <dynamicsFrameType>0</dynamicsFrameType>
    <dynamicsFramePadding>0.2</dynamicsFramePadding>
    <dynamicsFrameWidth>0.1</dynamicsFrameWidth>
    <dynamicsFrameRound>0</dynamicsFrameRound>
    <dynamicsFrameFgColor r="0" g="0" b="0" a="255"/>
    <dynamicsFrameBgColor r="255" g="255" b="255" a="0"/>
    <dynamicsPosition>center</dynamicsPosition>
    <expressionFontFace>MuseJazz Text</expressionFontFace>
    <expressionFontSize>10</expressionFontSize>
    <expressionLineSpacing>1</expressionLineSpacing>
    <expressionFontSpatiumDependent>1</expressionFontSpatiumDependent>
    <expressionFontStyle>2</expressionFontStyle>
    <expressionColor r="0" g="0" b="0" a="255"/>
    <expressionAlign>left,baseline</expressionAlign>
    <expressionPlacement>1</expressionPlacement>
    <expressionOffset x="0" y="2.5"/>
    <expressionPosAbove x="0" y="-1.5"/>
    <expressionPosBelow x="0" y="2.5"/>
    <expressionFrameType>0</expressionFrameType>
    <expressionFramePadding>0.2</expressionFramePadding>
    <expressionFrameWidth>0.1</expressionFrameWidth>
    <expressionFrameRound>0</expressionFrameRound>
    <expressionFrameFgColor r="0" g="0" b="0" a="255"/>
    <expressionFrameBgColor r="255" g="255" b="255" a="0"/>
    <expressionMinDistance>0.5</expressionMinDistance>
    <expressionPosition>left</expressionPosition>
    <tempoFontFace>MuseJazz Text</tempoFontFace>
    <tempoFontSize>12</tempoFontSize>
    <tempoLineSpacing>1</tempoLineSpacing>
    <tempoFontSpatiumDependent>1</tempoFontSpatiumDependent>
    <tempoFontStyle>1</tempoFontStyle>
    <tempoColor r="0" g="0" b="0" a="255"/>
    <tempoAlign>left,baseline</tempoAlign>
    <tempoSystemFlag>1</tempoSystemFlag>
    <tempoPlacement>0</tempoPlacement>
    <tempoPosAbove x="0" y="-2"/>
    <tempoPosBelow x="0" y="3"/>
    <tempoMinDistance>0.5</tempoMinDistance>
    <tempoFrameType>0</tempoFrameType>
    <tempoFramePadding>0.2</tempoFramePadding>
    <tempoFrameWidth>0.1</tempoFrameWidth>
    <tempoFrameRound>0</tempoFrameRound>
    <tempoFrameFgColor r="0" g="0" b="0" a="255"/>
    <tempoFrameBgColor r="255" g="255" b="255" a="0"/>
    <tempoPosition>left</tempoPosition>
    <tempoChangeFontFace>Edwin</tempoChangeFontFace>
    <tempoChangeFontSize>12</tempoChangeFontSize>
    <tempoChangeLineSpacing>1</tempoChangeLineSpacing>
    <tempoChangeFontSpatiumDependent>1</tempoChangeFontSpatiumDependent>
    <tempoChangeFontStyle>1</tempoChangeFontStyle>
    <tempoChangeColor r="0" g="0" b="0" a="255"/>
    <tempoChangeAlign>left,baseline</tempoChangeAlign>
    <tempoChangeSystemFlag>1</tempoChangeSystemFlag>
    <tempoChangePlacement>0</tempoChangePlacement>
    <tempoChangePosAbove x="0" y="-2"/>
    <tempoChangePosBelow x="0" y="3"/>
    <tempoChangeMinDistance>0.5</tempoChangeMinDistance>
    <tempoChangeFrameType>0</tempoChangeFrameType>
    <tempoChangeFramePadding>0.2</tempoChangeFramePadding>
    <tempoChangeFrameWidth>0.1</tempoChangeFrameWidth>
    <tempoChangeFrameRound>0</tempoChangeFrameRound>
    <tempoChangeFrameFgColor r="0" g="0" b="0" a="255"/>
    <tempoChangeFrameBgColor r="255" g="255" b="255" a="0"/>
    <tempoChangePosition>left</tempoChangePosition>
    <tempoChangeLineWidth>0.15</tempoChangeLineWidth>
    <tempoChangeLineStyle>dashed</tempoChangeLineStyle>
    <tempoChangeDashLineLen>6</tempoChangeDashLineLen>
    <tempoChangeDashGapLen>9</tempoChangeDashGapLen>
    <metronomeFontFace>MuseJazz Text</metronomeFontFace>
    <metronomeFontSize>12</metronomeFontSize>
    <metronomeLineSpacing>1</metronomeLineSpacing>
    <metronomeFontSpatiumDependent>0</metronomeFontSpatiumDependent>
    <metronomeFontStyle>0</metronomeFontStyle>
    <metronomeColor r="0" g="0" b="0" a="255"/>
    <metronomePlacement>0</metronomePlacement>
    <metronomeAlign>left,top</metronomeAlign>
    <metronomeOffset x="0" y="0"/>
    <metronomeFrameType>0</metronomeFrameType>
    <metronomeFramePadding>0.2</metronomeFramePadding>
    <metronomeFrameWidth>0.1</metronomeFrameWidth>
    <metronomeFrameRound>0</metronomeFrameRound>
    <metronomeFrameFgColor r="0" g="0" b="0" a="255"/>
    <metronomeFrameBgColor r="255" g="255" b="255" a="0"/>
    <metronomePosition>left</metronomePosition>
    <measureNumberFontFace>MuseJazz Text</measureNumberFontFace>
    <measureNumberFontSize>8</measureNumberFontSize>
    <measureNumberLineSpacing>1</measureNumberLineSpacing>
    <measureNumberFontSpatiumDependent>0</measureNumberFontSpatiumDependent>
    <measureNumberFontStyle>2</measureNumberFontStyle>
    <measureNumberColor r="0" g="0" b="0" a="255"/>
    <measureNumberPosAbove x="0" y="-2"/>
    <measureNumberPosBelow x="0" y="1"/>
    <measureNumberOffsetType>1</measureNumberOffsetType>
    <measureNumberVPlacement>0</measureNumberVPlacement>
    <measureNumberHPlacement>left</measureNumberHPlacement>
    <measureNumberMinDistance>0.5</measureNumberMinDistance>
    <measureNumberAlign>left,baseline</measureNumberAlign>
    <measureNumberFrameType>0</measureNumberFrameType>
    <measureNumberFramePadding>0.2</measureNumberFramePadding>
    <measureNumberFrameWidth>0.1</measureNumberFrameWidth>
    <measureNumberFrameRound>0</measureNumberFrameRound>
    <measureNumberFrameFgColor r="0" g="0" b="0" a="255"/>
    <measureNumberFrameBgColor r="255" g="255" b="255" a="0"/>
    <measureNumberPosition>left</measureNumberPosition>
    <measureNumberTextStyle>measure_number</measureNumberTextStyle>
    <measureNumberAlignToBarline>1</measureNumberAlignToBarline>
    <measureNumberAlternateFontFace>Edwin</measureNumberAlternateFontFace>
    <measureNumberAlternateFontSize>10</measureNumberAlternateFontSize>
    <measureNumberAlternateLineSpacing>1</measureNumberAlternateLineSpacing>
    <measureNumberAlternateFontSpatiumDependent>0</measureNumberAlternateFontSpatiumDependent>
    <measureNumberAlternateFontStyle>3</measureNumberAlternateFontStyle>
    <measureNumberAlternateColor r="0" g="0" b="0" a="255"/>
    <measureNumberAlternateAlign>left,baseline</measureNumberAlternateAlign>
    <measureNumberAlternatePosAbove x="0" y="-4"/>
    <measureNumberAlternatePosBelow x="0" y="4"/>
    <measureNumberAlternateFrameType>1</measureNumberAlternateFrameType>
    <measureNumberAlternateFramePadding>0.3</measureNumberAlternateFramePadding>
    <measureNumberAlternateFrameWidth>0.1</measureNumberAlternateFrameWidth>
    <measureNumberAlternateFrameRound>0</measureNumberAlternateFrameRound>
    <measureNumberAlternateFrameFgColor r="0" g="0" b="0" a="255"/>
    <measureNumberAlternateFrameBgColor r="255" g="255" b="255" a="0"/>
    <measureNumberAlternatePosition>left</measureNumberAlternatePosition>
    <mmRestShowMeasureNumberRange>0</mmRestShowMeasureNumberRange>
    <mmRestRangeBracketType>0</mmRestRangeBracketType>
    <mmRestRangeFontFace>Edwin</mmRestRangeFontFace>
    <mmRestRangeFontSize>8</mmRestRangeFontSize>
    <mmRestRangeFontSpatiumDependent>0</mmRestRangeFontSpatiumDependent>
    <mmRestRangeFontStyle>2</mmRestRangeFontStyle>
    <mmRestRangeColor r="0" g="0" b="0" a="255"/>
    <mmRestRangePosAbove x="0" y="-3"/>
    <mmRestRangePosBelow x="0" y="1"/>
    <mmRestRangeOffsetType>1</mmRestRangeOffsetType>
    <mmRestRangeVPlacement>1</mmRestRangeVPlacement>
    <mmRestRangeHPlacement>center</mmRestRangeHPlacement>
    <mmRestRangeAlign>center,baseline</mmRestRangeAlign>
    <mmRestRangeFrameType>0</mmRestRangeFrameType>
    <mmRestRangeFramePadding>0.2</mmRestRangeFramePadding>
    <mmRestRangeFrameWidth>0.1</mmRestRangeFrameWidth>
    <mmRestRangeFrameRound>0</mmRestRangeFrameRound>
    <mmRestRangeFrameFgColor r="0" g="0" b="0" a="255"/>
    <mmRestRangeFrameBgColor r="255" g="255" b="255" a="0"/>
    <mmRestRangePosition>center</mmRestRangePosition>
    <mmRestRangeMinDistance>0.5</mmRestRangeMinDistance>
    <mmRestRangeTextStyle>mmrest_range</mmRestRangeTextStyle>
    <translatorFontFace>MuseJazz Text</translatorFontFace>
    <translatorFontSize>10</translatorFontSize>
    <translatorLineSpacing>1</translatorLineSpacing>
    <translatorFontSpatiumDependent>0</translatorFontSpatiumDependent>
    <translatorFontStyle>0</translatorFontStyle>
    <translatorColor r="0" g="0" b="0" a="255"/>
    <translatorAlign>left,top</translatorAlign>
    <translatorOffset x="0" y="0"/>
    <translatorFrameType>0</translatorFrameType>
    <translatorFramePadding>0.2</translatorFramePadding>
    <translatorFrameWidth>0.1</translatorFrameWidth>
    <translatorFrameRound>0</translatorFrameRound>
    <translatorFrameFgColor r="0" g="0" b="0" a="255"/>
    <translatorFrameBgColor r="255" g="255" b="255" a="0"/>
    <translatorPosition>left</translatorPosition>
    <systemTextFontFace>MuseJazz Text</systemTextFontFace>
    <systemTextFontSize>10</systemTextFontSize>
    <systemTextLineSpacing>1</systemTextLineSpacing>
    <systemTextFontSpatiumDependent>1</systemTextFontSpatiumDependent>
    <systemTextFontStyle>0</systemTextFontStyle>
    <systemTextColor r="0" g="0" b="0" a="255"/>
    <systemTextAlign>left,baseline</systemTextAlign>
    <systemTextOffsetType>1</systemTextOffsetType>
    <systemTextPlacement>0</systemTextPlacement>
    <systemTextPosAbove x="0" y="-2"/>
    <systemTextPosBelow x="0" y="3.5"/>
    <systemTextMinDistance>0.5</systemTextMinDistance>
    <systemTextFrameType>0</systemTextFrameType>
    <systemTextFramePadding>0.2</systemTextFramePadding>
    <systemTextFrameWidth>0.1</systemTextFrameWidth>
    <systemTextFrameRound>0</systemTextFrameRound>
    <systemTextFrameFgColor r="0" g="0" b="0" a="255"/>
    <systemTextFrameBgColor r="255" g="255" b="255" a="0"/>
    <systemTextPosition>left</systemTextPosition>
    <staffTextFontFace>MuseJazz Text</staffTextFontFace>
    <staffTextFontSize>10</staffTextFontSize>
    <staffTextLineSpacing>1</staffTextLineSpacing>
    <staffTextFontSpatiumDependent>1</staffTextFontSpatiumDependent>
    <staffTextFontStyle>0</staffTextFontStyle>
    <staffTextColor r="0" g="0" b="0" a="255"/>
    <staffTextAlign>left,baseline</staffTextAlign>
    <staffTextOffsetType>1</staffTextOffsetType>
    <staffTextPlacement>1</staffTextPlacement>
    <staffTextPosAbove x="0" y="-1"/>
    <staffTextPosBelow x="0" y="2.5"/>
    <staffTextMinDistance>0.5</staffTextMinDistance>
    <staffTextFrameType>0</staffTextFrameType>
    <staffTextFramePadding>0.2</staffTextFramePadding>
    <staffTextFrameWidth>0.1</staffTextFrameWidth>
    <staffTextFrameRound>0</staffTextFrameRound>
    <staffTextFrameFgColor r="0" g="0" b="0" a="255"/>
    <staffTextFrameBgColor r="255" g="255" b="255" a="0"/>
    <staffTextPosition>left</staffTextPosition>
    <fretDiagramFingeringFontFace>FreeSans</fretDiagramFingeringFontFace>
    <fretDiagramFingeringFontSize>6</fretDiagramFingeringFontSize>
    <fretDiagramFingeringLineSpacing>1</fretDiagramFingeringLineSpacing>
    <fretDiagramFingeringFontSpatiumDependent>1</fretDiagramFingeringFontSpatiumDependent>
    <fretDiagramFingeringFontStyle>0</fretDiagramFingeringFontStyle>
    <fretDiagramFingeringColor r="0" g="0" b="0" a="255"/>
    <fretDiagramFingeringAlign>left,baseline</fretDiagramFingeringAlign>
    <fretDiagramFingeringPosAbove x="0" y="-1"/>
    <fretDiagramFingeringFrameType>0</fretDiagramFingeringFrameType>
    <fretDiagramFingeringFramePadding>0.2</fretDiagramFingeringFramePadding>
    <fretDiagramFingeringFrameWidth>0.1</fretDiagramFingeringFrameWidth>
    <fretDiagramFingeringFrameRound>0</fretDiagramFingeringFrameRound>
    <fretDiagramFingeringFrameFgColor r="0" g="0" b="0" a="255"/>
    <fretDiagramFingeringFrameBgColor r="255" g="255" b="255" a="0"/>
    <fretDiagramFingeringPosition>left</fretDiagramFingeringPosition>
    <fretDiagramFretNumberFontFace>FreeSans</fretDiagramFretNumberFontFace>
    <fretDiagramFretNumberFontSize>6</fretDiagramFretNumberFontSize>
    <fretDiagramFretNumberLineSpacing>1</fretDiagramFretNumberLineSpacing>
    <fretDiagramFretNumberFontSpatiumDependent>1</fretDiagramFretNumberFontSpatiumDependent>
    <fretDiagramFretNumberFontStyle>0</fretDiagramFretNumberFontStyle>
    <fretDiagramFretNumberColor r="0" g="0" b="0" a="255"/>
    <fretDiagramFretNumberAlign>left,baseline</fretDiagramFretNumberAlign>
    <fretDiagramFretNumberPosAbove x="0" y="-1"/>
    <fretDiagramFretNumberFrameType>0</fretDiagramFretNumberFrameType>
    <fretDiagramFretNumberFramePadding>0.2</fretDiagramFretNumberFramePadding>
    <fretDiagramFretNumberFrameWidth>0.1</fretDiagramFretNumberFrameWidth>
    <fretDiagramFretNumberFrameRound>0</fretDiagramFretNumberFrameRound>
    <fretDiagramFretNumberFrameFgColor r="0" g="0" b="0" a="255"/>
    <fretDiagramFretNumberFrameBgColor r="255" g="255" b="255" a="0"/>
    <fretDiagramFretNumberPosition>left</fretDiagramFretNumberPosition>
    <rehearsalMarkFontFace>MuseJazz Text</rehearsalMarkFontFace>
    <rehearsalMarkFontSize>14</rehearsalMarkFontSize>
    <rehearsalMarkLineSpacing>1</rehearsalMarkLineSpacing>
    <rehearsalMarkFontSpatiumDependent>1</rehearsalMarkFontSpatiumDependent>
    <rehearsalMarkFontStyle>1</rehearsalMarkFontStyle>
    <rehearsalMarkColor r="0" g="0" b="0" a="255"/>
    <rehearsalMarkAlign>right,baseline</rehearsalMarkAlign>
    <rehearsalMarkFrameType>1</rehearsalMarkFrameType>
    <rehearsalMarkFramePadding>0.5</rehearsalMarkFramePadding>
    <rehearsalMarkFrameWidth>0.16</rehearsalMarkFrameWidth>
    <rehearsalMarkFrameRound>0</rehearsalMarkFrameRound>
    <rehearsalMarkFrameFgColor r="0" g="0" b="0" a="255"/>
    <rehearsalMarkFrameBgColor r="255" g="255" b="255" a="0"/>
    <rehearsalMarkPosition>center</rehearsalMarkPosition>
    <rehearsalMarkPlacement>0</rehearsalMarkPlacement>
    <rehearsalMarkPosAbove x="0" y="-3"/>
    <rehearsalMarkPosBelow x="0" y="4"/>
    <rehearsalMarkMinDistance>0.5</rehearsalMarkMinDistance>
    <repeatPlayCountFontFace>Edwin</repeatPlayCountFontFace>
    <repeatPlayCountFontSize>10</repeatPlayCountFontSize>
    <repeatPlayCountLineSpacing>1</repeatPlayCountLineSpacing>
    <repeatPlayCountFontSpatiumDependent>1</repeatPlayCountFontSpatiumDependent>
    <repeatPlayCountFontStyle>0</repeatPlayCountFontStyle>
    <repeatPlayCountColor r="0" g="0" b="0" a="255"/>
    <repeatPlayCountAlign>left,baseline</repeatPlayCountAlign>
    <repeatPlayCountPlacement>0</repeatPlayCountPlacement>
    <repeatPlayCountFrameType>0</repeatPlayCountFrameType>
    <repeatPlayCountFramePadding>0.2</repeatPlayCountFramePadding>
    <repeatPlayCountFrameWidth>0.1</repeatPlayCountFrameWidth>
    <repeatPlayCountFrameRound>0</repeatPlayCountFrameRound>
    <repeatPlayCountFrameFgColor r="0" g="0" b="0" a="255"/>
    <repeatPlayCountFrameBgColor r="255" g="255" b="255" a="0"/>
    <repeatPlayCountPosition>left</repeatPlayCountPosition>
    <repeatPlayCountPosAbove x="0" y="-2"/>
    <repeatPlayCountPosBelow x="0" y="4"/>
    <repeatPlayCountMinDistance>0.5</repeatPlayCountMinDistance>
    <repeatLeftFontFace>MuseJazz Text</repeatLeftFontFace>
    <repeatLeftFontSize>18</repeatLeftFontSize>
    <repeatLeftLineSpacing>1</repeatLeftLineSpacing>
    <repeatLeftFontSpatiumDependent>1</repeatLeftFontSpatiumDependent>
    <repeatLeftFontStyle>0</repeatLeftFontStyle>
    <repeatLeftColor r="0" g="0" b="0" a="255"/>
    <repeatLeftAlign>left,baseline</repeatLeftAlign>
    <repeatLeftPlacement>0</repeatLeftPlacement>
    <repeatLeftFrameType>0</repeatLeftFrameType>
    <repeatLeftFramePadding>0.2</repeatLeftFramePadding>
    <repeatLeftFrameWidth>0.1</repeatLeftFrameWidth>
    <repeatLeftFrameRound>0</repeatLeftFrameRound>
    <repeatLeftFrameFgColor r="0" g="0" b="0" a="255"/>
    <repeatLeftFrameBgColor r="255" g="255" b="255" a="0"/>
    <repeatLeftPosition>left</repeatLeftPosition>
    <repeatRightFontFace>MuseJazz Text</repeatRightFontFace>
    <repeatRightFontSize>11</repeatRightFontSize>
    <repeatRightLineSpacing>1</repeatRightLineSpacing>
    <repeatRightFontSpatiumDependent>1</repeatRightFontSpatiumDependent>
    <repeatRightFontStyle>0</repeatRightFontStyle>
    <repeatRightColor r="0" g="0" b="0" a="255"/>
    <repeatRightAlign>right,baseline</repeatRightAlign>
    <repeatRightPlacement>0</repeatRightPlacement>
    <repeatRightFrameType>0</repeatRightFrameType>
    <repeatRightFramePadding>0.2</repeatRightFramePadding>
    <repeatRightFrameWidth>0.1</repeatRightFrameWidth>
    <repeatRightFrameRound>0</repeatRightFrameRound>
    <repeatRightFrameFgColor r="0" g="0" b="0" a="255"/>
    <repeatRightFrameBgColor r="255" g="255" b="255" a="0"/>
    <repeatRightPosition>right</repeatRightPosition>
    <frameFontFace>MuseJazz Text</frameFontFace>
    <frameFontSize>10</frameFontSize>
    <frameLineSpacing>1</frameLineSpacing>
    <frameFontSpatiumDependent>0</frameFontSpatiumDependent>
    <frameFontStyle>0</frameFontStyle>
    <frameColor r="0" g="0" b="0" a="255"/>
    <frameAlign>left,top</frameAlign>
    <frameOffset x="0" y="0"/>
    <frameFrameType>0</frameFrameType>
    <frameFramePadding>0.2</frameFramePadding>
    <frameFrameWidth>0.1</frameFrameWidth>
    <frameFrameRound>0</frameFrameRound>
    <frameFrameFgColor r="0" g="0" b="0" a="255"/>
    <frameFrameBgColor r="255" g="255" b="255" a="0"/>
    <framePosition>left</framePosition>
    <textLineFontFace>MuseJazz Text</textLineFontFace>
    <textLineFontSize>10</textLineFontSize>
    <textLineLineSpacing>1</textLineLineSpacing>
    <textLineFontSpatiumDependent>1</textLineFontSpatiumDependent>
    <textLineFontStyle>0</textLineFontStyle>
    <textLineColor r="0" g="0" b="0" a="255"/>
    <textLineTextAlign>left,center</textLineTextAlign>
    <textLineSystemFlag>0</textLineSystemFlag>
    <systemTextLineFontFace>Edwin</systemTextLineFontFace>
    <systemTextLineFontSize>12</systemTextLineFontSize>
    <systemTextLineFontSpatiumDependent>1</systemTextLineFontSpatiumDependent>
    <systemTextLineFontStyle>0</systemTextLineFontStyle>
    <systemTextLineColor r="0" g="0" b="0" a="255"/>
    <systemTextLineTextAlign>left,center</systemTextLineTextAlign>
    <systemTextLineSystemFlag>1</systemTextLineSystemFlag>
    <noteLinePlacement>0</noteLinePlacement>
    <noteLineFontFace>Edwin</noteLineFontFace>
    <noteLineFontSize>10</noteLineFontSize>
    <noteLineLineSpacing>1</noteLineLineSpacing>
    <noteLineFontSpatiumDependent>1</noteLineFontSpatiumDependent>
    <noteLineFontStyle>0</noteLineFontStyle>
    <noteLineColor r="0" g="0" b="0" a="255"/>
    <noteLineAlign>left,center</noteLineAlign>
    <noteLineOffset x="0" y="0"/>
    <noteLineFrameType>0</noteLineFrameType>
    <noteLineFramePadding>0.2</noteLineFramePadding>
    <noteLineFrameWidth>0.1</noteLineFrameWidth>
    <noteLineFrameRound>0</noteLineFrameRound>
    <noteLineFrameFgColor r="0" g="0" b="0" a="255"/>
    <noteLineFrameBgColor r="255" g="255" b="255" a="0"/>
    <noteLinePosition>left</noteLinePosition>
    <noteLineWidth>0.15</noteLineWidth>
    <noteLineStyle>solid</noteLineStyle>
    <noteLineDashLineLen>5</noteLineDashLineLen>
    <noteLineDashGapLen>5</noteLineDashGapLen>
    <glissandoFontFace>MuseJazz Text</glissandoFontFace>
    <glissandoFontSize>8</glissandoFontSize>
    <glissandoLineSpacing>1</glissandoLineSpacing>
    <glissandoFontSpatiumDependent>1</glissandoFontSpatiumDependent>
    <glissandoFontStyle>2</glissandoFontStyle>
    <glissandoColor r="0" g="0" b="0" a="255"/>
    <glissandoAlign>left,top</glissandoAlign>
    <glissandoOffset x="0" y="0"/>
    <glissandoFrameType>0</glissandoFrameType>
    <glissandoFramePadding>0.2</glissandoFramePadding>
    <glissandoFrameWidth>0.1</glissandoFrameWidth>
    <glissandoFrameRound>0</glissandoFrameRound>
    <glissandoFrameFgColor r="0" g="0" b="0" a="255"/>
    <glissandoFrameBgColor r="255" g="255" b="255" a="0"/>
    <glissandoPosition>left</glissandoPosition>
    <glissandoLineWidth>0.15</glissandoLineWidth>
    <glissandoText>gliss.</glissandoText>
    <glissandoStyle>0</glissandoStyle>
    <glissandoStyleHarp>3</glissandoStyleHarp>
    <glissandoType>0</glissandoType>
    <glissandoLineStyle>solid</glissandoLineStyle>
    <glissandoDashLineLen>5</glissandoDashLineLen>
    <glissandoDashGapLen>5</glissandoDashGapLen>
    <glissandoShowText>1</glissandoShowText>
    <bendFontFace>MuseJazz Text</bendFontFace>
    <bendFontSize>8</bendFontSize>
    <bendLineSpacing>1</bendLineSpacing>
    <bendFontSpatiumDependent>1</bendFontSpatiumDependent>
    <bendFontStyle>0</bendFontStyle>
    <bendColor r="0" g="0" b="0" a="255"/>
    <bendAlign>left,baseline</bendAlign>
    <bendOffset x="0" y="0"/>
    <bendFrameType>0</bendFrameType>
    <bendFramePadding>0.2</bendFramePadding>
    <bendFrameWidth>0.1</bendFrameWidth>
    <bendFrameRound>0</bendFrameRound>
    <bendFrameFgColor r="0" g="0" b="0" a="255"/>
    <bendFrameBgColor r="255" g="255" b="255" a="0"/>
    <bendPosition>left</bendPosition>
    <bendLineWidth>0.15</bendLineWidth>
    <bendArrowWidth>0.5</bendArrowWidth>
    <guitarBendLineWidth>0.13</guitarBendLineWidth>
    <guitarBendLineWidthTab>0.15</guitarBendLineWidthTab>
    <guitarBendHeightAboveTABStaff>1.5</guitarBendHeightAboveTABStaff>
    <guitarBendPartialBendHeight>1.5</guitarBendPartialBendHeight>
    <guitarBendUseFull>0</guitarBendUseFull>
    <guitarBendArrowWidth>1</guitarBendArrowWidth>
    <guitarBendArrowHeight>1</guitarBendArrowHeight>
    <useCueSizeFretForGraceBends>0</useCueSizeFretForGraceBends>
    <headerFontFace>MuseJazz Text</headerFontFace>
    <headerFontSize>11</headerFontSize>
    <headerLineSpacing>1</headerLineSpacing>
    <headerFontSpatiumDependent>0</headerFontSpatiumDependent>
    <headerFontStyle>1</headerFontStyle>
    <headerColor r="0" g="0" b="0" a="255"/>
    <headerAlign>center,center</headerAlign>
    <headerOffset x="0" y="0"/>
    <headerFrameType>0</headerFrameType>
    <headerFramePadding>0.2</headerFramePadding>
    <headerFrameWidth>0.1</headerFrameWidth>
    <headerFrameRound>0</headerFrameRound>
    <headerFrameFgColor r="0" g="0" b="0" a="255"/>
    <headerFrameBgColor r="255" g="255" b="255" a="0"/>
    <headerPosition>center</headerPosition>
    <footerFontFace>MuseJazz Text</footerFontFace>
    <footerFontSize>9</footerFontSize>
    <footerLineSpacing>1</footerLineSpacing>
    <footerFontSpatiumDependent>0</footerFontSpatiumDependent>
    <footerFontStyle>0</footerFontStyle>
    <footerColor r="0" g="0" b="0" a="255"/>
    <footerAlign>center,center</footerAlign>
    <footerOffset x="0" y="5"/>
    <footerFrameType>0</footerFrameType>
    <footerFramePadding>0.2</footerFramePadding>
    <footerFrameWidth>0.1</footerFrameWidth>
    <footerFrameRound>0</footerFrameRound>
    <footerFrameFgColor r="0" g="0" b="0" a="255"/>
    <footerFrameBgColor r="255" g="255" b="255" a="0"/>
    <footerPosition>center</footerPosition>
    <copyrightFontFace>Edwin</copyrightFontFace>
    <copyrightFontSize>9</copyrightFontSize>
    <copyrightLineSpacing>1</copyrightLineSpacing>
    <copyrightFontSpatiumDependent>0</copyrightFontSpatiumDependent>
    <copyrightFontStyle>0</copyrightFontStyle>
    <copyrightColor r="0" g="0" b="0" a="255"/>
    <copyrightAlign>center,center</copyrightAlign>
    <copyrightOffset x="0" y="5"/>
    <copyrightFrameType>0</copyrightFrameType>
    <copyrightFramePadding>0.2</copyrightFramePadding>
    <copyrightFrameWidth>0.1</copyrightFrameWidth>
    <copyrightFrameRound>0</copyrightFrameRound>
    <copyrightFrameFgColor r="0" g="0" b="0" a="255"/>
    <copyrightFrameBgColor r="255" g="255" b="255" a="0"/>
    <copyrightPosition>center</copyrightPosition>
    <pageNumberFontFace>MuseJazz Text</pageNumberFontFace>
    <pageNumberFontSize>11</pageNumberFontSize>
    <pageNumberLineSpacing>1</pageNumberLineSpacing>
    <pageNumberFontSpatiumDependent>0</pageNumberFontSpatiumDependent>
    <pageNumberFontStyle>1</pageNumberFontStyle>
    <pageNumberColor r="0" g="0" b="0" a="255"/>
    <pageNumberAlign>center,center</pageNumberAlign>
    <pageNumberOffset x="0" y="0"/>
    <pageNumberFrameType>0</pageNumberFrameType>
    <pageNumberFramePadding>0.2</pageNumberFramePadding>
    <pageNumberFrameWidth>0.1</pageNumberFrameWidth>
    <pageNumberFrameRound>0</pageNumberFrameRound>
    <pageNumberFrameFgColor r="0" g="0" b="0" a="255"/>
    <pageNumberFrameBgColor r="255" g="255" b="255" a="0"/>
    <pageNumberPosition>center</pageNumberPosition>
    <instrumentChangeFontFace>MuseJazz Text</instrumentChangeFontFace>
    <instrumentChangeFontSize>10</instrumentChangeFontSize>
    <instrumentChangeLineSpacing>1</instrumentChangeLineSpacing>
    <instrumentChangeFontSpatiumDependent>1</instrumentChangeFontSpatiumDependent>
    <instrumentChangeFontStyle>1</instrumentChangeFontStyle>
    <instrumentChangeColor r="0" g="0" b="0" a="255"/>
    <instrumentChangeAlign>left,baseline</instrumentChangeAlign>
    <instrumentChangeOffset x="0" y="0"/>
    <instrumentChangePlacement>0</instrumentChangePlacement>
    <instrumentChangePosAbove x="0" y="-2"/>
    <instrumentChangePosBelow x="0" y="3.5"/>
    <instrumentChangeMinDistance>0.5</instrumentChangeMinDistance>
    <instrumentChangeFrameType>0</instrumentChangeFrameType>
    <instrumentChangeFramePadding>0.2</instrumentChangeFramePadding>
    <instrumentChangeFrameWidth>0.1</instrumentChangeFrameWidth>
    <instrumentChangeFrameRound>0</instrumentChangeFrameRound>
    <instrumentChangeFrameFgColor r="0" g="0" b="0" a="255"/>
    <instrumentChangeFrameBgColor r="255" g="255" b="255" a="0"/>
    <instrumentChangePosition>left</instrumentChangePosition>
    <stickingFontFace>Edwin</stickingFontFace>
    <stickingFontSize>10</stickingFontSize>
    <stickingLineSpacing>1</stickingLineSpacing>
    <stickingFontSpatiumDependent>1</stickingFontSpatiumDependent>
    <stickingFontStyle>0</stickingFontStyle>
    <stickingColor r="0" g="0" b="0" a="255"/>
    <stickingAlign>left,baseline</stickingAlign>
    <stickingOffset x="0" y="0"/>
    <stickingPlacement>1</stickingPlacement>
    <stickingPosAbove x="0" y="-2"/>
    <stickingPosBelow x="0" y="2"/>
    <stickingMinDistance>0.5</stickingMinDistance>
    <stickingFrameType>0</stickingFrameType>
    <stickingFramePadding>0.2</stickingFramePadding>
    <stickingFrameWidth>0.1</stickingFrameWidth>
    <stickingFrameRound>0</stickingFrameRound>
    <stickingFrameFgColor r="0" g="0" b="0" a="255"/>
    <stickingFrameBgColor r="255" g="255" b="255" a="0"/>
    <stickingPosition>left</stickingPosition>
    <figuredBassFontFace>MScoreBC</figuredBassFontFace>
    <figuredBassFontSize>8</figuredBassFontSize>
    <figuredBassLineSpacing>1</figuredBassLineSpacing>
    <figuredBassFontSpatiumDependent>1</figuredBassFontSpatiumDependent>
    <figuredBassFontStyle>0</figuredBassFontStyle>
    <figuredBassColor r="0" g="0" b="0" a="255"/>
    <user1Name></user1Name>
    <user1FontFace>MuseJazz Text</user1FontFace>
    <user1FontSize>10</user1FontSize>
    <user1LineSpacing>1</user1LineSpacing>
    <user1FontSpatiumDependent>1</user1FontSpatiumDependent>
    <user1FontStyle>0</user1FontStyle>
    <user1Color r="0" g="0" b="0" a="255"/>
    <user1Align>left,top</user1Align>
    <user1Offset x="0" y="0"/>
    <user1OffsetType>1</user1OffsetType>
    <user1FrameType>0</user1FrameType>
    <user1FramePadding>0.2</user1FramePadding>
    <user1FrameWidth>0.1</user1FrameWidth>
    <user1FrameRound>0</user1FrameRound>
    <user1FrameFgColor r="0" g="0" b="0" a="255"/>
    <user1FrameBgColor r="255" g="255" b="255" a="0"/>
    <user1Position>left</user1Position>
    <user2Name></user2Name>
    <user2FontFace>MuseJazz Text</user2FontFace>
    <user2FontSize>10</user2FontSize>
    <user2LineSpacing>1</user2LineSpacing>
    <user2FontSpatiumDependent>1</user2FontSpatiumDependent>
    <user2FontStyle>0</user2FontStyle>
    <user2Color r="0" g="0" b="0" a="255"/>
    <user2Align>left,top</user2Align>
    <user2Offset x="0" y="0"/>
    <user2OffsetType>1</user2OffsetType>
    <user2FrameType>0</user2FrameType>
    <user2FramePadding>0.2</user2FramePadding>
    <user2FrameWidth>0.1</user2FrameWidth>
    <user2FrameRound>0</user2FrameRound>
    <user2FrameFgColor r="0" g="0" b="0" a="255"/>
    <user2FrameBgColor r="255" g="255" b="255" a="0"/>
    <user2Position>left</user2Position>
    <user3Name></user3Name>
    <user3FontFace>MuseJazz Text</user3FontFace>
    <user3FontSize>10</user3FontSize>
    <user3LineSpacing>1</user3LineSpacing>
    <user3FontSpatiumDependent>1</user3FontSpatiumDependent>
    <user3FontStyle>0</user3FontStyle>
    <user3Color r="0" g="0" b="0" a="255"/>
    <user3Align>left,top</user3Align>
    <user3Offset x="0" y="0"/>
    <user3OffsetType>1</user3OffsetType>
    <user3FrameType>0</user3FrameType>
    <user3FramePadding>0.2</user3FramePadding>
    <user3FrameWidth>0.1</user3FrameWidth>
    <user3FrameRound>0</user3FrameRound>
    <user3FrameFgColor r="0" g="0" b="0" a="255"/>
    <user3FrameBgColor r="255" g="255" b="255" a="0"/>
    <user3Position>left</user3Position>
    <user4Name></user4Name>
    <user4FontFace>MuseJazz Text</user4FontFace>
    <user4FontSize>10</user4FontSize>
    <user4LineSpacing>1</user4LineSpacing>
    <user4FontSpatiumDependent>1</user4FontSpatiumDependent>
    <user4FontStyle>0</user4FontStyle>
    <user4Color r="0" g="0" b="0" a="255"/>
    <user4Align>left,top</user4Align>
    <user4Offset x="0" y="0"/>
    <user4OffsetType>1</user4OffsetType>
    <user4FrameType>0</user4FrameType>
    <user4FramePadding>0.2</user4FramePadding>
    <user4FrameWidth>0.1</user4FrameWidth>
    <user4FrameRound>0</user4FrameRound>
    <user4FrameFgColor r="0" g="0" b="0" a="255"/>
    <user4FrameBgColor r="255" g="255" b="255" a="0"/>
    <user4Position>left</user4Position>
    <user5Name></user5Name>
    <user5FontFace>MuseJazz Text</user5FontFace>
    <user5FontSize>10</user5FontSize>
    <user5LineSpacing>1</user5LineSpacing>
    <user5FontSpatiumDependent>1</user5FontSpatiumDependent>
    <user5FontStyle>0</user5FontStyle>
    <user5Color r="0" g="0" b="0" a="255"/>
    <user5Align>left,top</user5Align>
    <user5Offset x="0" y="0"/>
    <user5OffsetType>1</user5OffsetType>
    <user5FrameType>0</user5FrameType>
    <user5FramePadding>0.2</user5FramePadding>
    <user5FrameWidth>0.1</user5FrameWidth>
    <user5FrameRound>0</user5FrameRound>
    <user5FrameFgColor r="0" g="0" b="0" a="255"/>
    <user5FrameBgColor r="255" g="255" b="255" a="0"/>
    <user5Position>left</user5Position>
    <user6Name></user6Name>
    <user6FontFace>MuseJazz Text</user6FontFace>
    <user6FontSize>10</user6FontSize>
    <user6LineSpacing>1</user6LineSpacing>
    <user6FontSpatiumDependent>1</user6FontSpatiumDependent>
    <user6FontStyle>0</user6FontStyle>
    <user6Color r="0" g="0" b="0" a="255"/>
    <user6Align>left,top</user6Align>
    <user6Offset x="0" y="0"/>
    <user6OffsetType>1</user6OffsetType>
    <user6FrameType>0</user6FrameType>
    <user6FramePadding>0.2</user6FramePadding>
    <user6FrameWidth>0.1</user6FrameWidth>
    <user6FrameRound>0</user6FrameRound>
    <user6FrameFgColor r="0" g="0" b="0" a="255"/>
    <user6FrameBgColor r="255" g="255" b="255" a="0"/>
    <user6Position>left</user6Position>
    <user7Name></user7Name>
    <user7FontFace>Edwin</user7FontFace>
    <user7FontSize>10</user7FontSize>
    <user7LineSpacing>1</user7LineSpacing>
    <user7FontSpatiumDependent>1</user7FontSpatiumDependent>
    <user7FontStyle>0</user7FontStyle>
    <user7Color r="0" g="0" b="0" a="255"/>
    <user7Align>left,top</user7Align>
    <user7Offset x="0" y="0"/>
    <user7OffsetType>1</user7OffsetType>
    <user7FrameType>0</user7FrameType>
    <user7FramePadding>0.2</user7FramePadding>
    <user7FrameWidth>0.1</user7FrameWidth>
    <user7FrameRound>0</user7FrameRound>
    <user7FrameFgColor r="0" g="0" b="0" a="255"/>
    <user7FrameBgColor r="255" g="255" b="255" a="0"/>
    <user7Position>left</user7Position>
    <user8Name></user8Name>
    <user8FontFace>Edwin</user8FontFace>
    <user8FontSize>10</user8FontSize>
    <user8LineSpacing>1</user8LineSpacing>
    <user8FontSpatiumDependent>1</user8FontSpatiumDependent>
    <user8FontStyle>0</user8FontStyle>
    <user8Color r="0" g="0" b="0" a="255"/>
    <user8Align>left,top</user8Align>
    <user8Offset x="0" y="0"/>
    <user8OffsetType>1</user8OffsetType>
    <user8FrameType>0</user8FrameType>
    <user8FramePadding>0.2</user8FramePadding>
    <user8FrameWidth>0.1</user8FrameWidth>
    <user8FrameRound>0</user8FrameRound>
    <user8FrameFgColor r="0" g="0" b="0" a="255"/>
    <user8FrameBgColor r="255" g="255" b="255" a="0"/>
    <user8Position>left</user8Position>
    <user9Name></user9Name>
    <user9FontFace>Edwin</user9FontFace>
    <user9FontSize>10</user9FontSize>
    <user9LineSpacing>1</user9LineSpacing>
    <user9FontSpatiumDependent>1</user9FontSpatiumDependent>
    <user9FontStyle>0</user9FontStyle>
    <user9Color r="0" g="0" b="0" a="255"/>
    <user9Align>left,top</user9Align>
    <user9Offset x="0" y="0"/>
    <user9OffsetType>1</user9OffsetType>
    <user9FrameType>0</user9FrameType>
    <user9FramePadding>0.2</user9FramePadding>
    <user9FrameWidth>0.1</user9FrameWidth>
    <user9FrameRound>0</user9FrameRound>
    <user9FrameFgColor r="0" g="0" b="0" a="255"/>
    <user9FrameBgColor r="255" g="255" b="255" a="0"/>
    <user9Position>left</user9Position>
    <user10Name></user10Name>
    <user10FontFace>Edwin</user10FontFace>
    <user10FontSize>10</user10FontSize>
    <user10LineSpacing>1</user10LineSpacing>
    <user10FontSpatiumDependent>1</user10FontSpatiumDependent>
    <user10FontStyle>0</user10FontStyle>
    <user10Color r="0" g="0" b="0" a="255"/>
    <user10Align>left,top</user10Align>
    <user10Offset x="0" y="0"/>
    <user10OffsetType>1</user10OffsetType>
    <user10FrameType>0</user10FrameType>
    <user10FramePadding>0.2</user10FramePadding>
    <user10FrameWidth>0.1</user10FrameWidth>
    <user10FrameRound>0</user10FrameRound>
    <user10FrameFgColor r="0" g="0" b="0" a="255"/>
    <user10FrameBgColor r="255" g="255" b="255" a="0"/>
    <user10Position>left</user10Position>
    <user11Name></user11Name>
    <user11FontFace>Edwin</user11FontFace>
    <user11FontSize>10</user11FontSize>
    <user11LineSpacing>1</user11LineSpacing>
    <user11FontSpatiumDependent>1</user11FontSpatiumDependent>
    <user11FontStyle>0</user11FontStyle>
    <user11Color r="0" g="0" b="0" a="255"/>
    <user11Align>left,top</user11Align>
    <user11Offset x="0" y="0"/>
    <user11OffsetType>1</user11OffsetType>
    <user11FrameType>0</user11FrameType>
    <user11FramePadding>0.2</user11FramePadding>
    <user11FrameWidth>0.1</user11FrameWidth>
    <user11FrameRound>0</user11FrameRound>
    <user11FrameFgColor r="0" g="0" b="0" a="255"/>
    <user11FrameBgColor r="255" g="255" b="255" a="0"/>
    <user11Position>left</user11Position>
    <user12Name></user12Name>
    <user12FontFace>Edwin</user12FontFace>
    <user12FontSize>10</user12FontSize>
    <user12LineSpacing>1</user12LineSpacing>
    <user12FontSpatiumDependent>1</user12FontSpatiumDependent>
    <user12FontStyle>0</user12FontStyle>
    <user12Color r="0" g="0" b="0" a="255"/>
    <user12Align>left,top</user12Align>
    <user12Offset x="0" y="0"/>
    <user12OffsetType>1</user12OffsetType>
    <user12FrameType>0</user12FrameType>
    <user12FramePadding>0.2</user12FramePadding>
    <user12FrameWidth>0.1</user12FrameWidth>
    <user12FrameRound>0</user12FrameRound>
    <user12FrameFgColor r="0" g="0" b="0" a="255"/>
    <user12FrameBgColor r="255" g="255" b="255" a="0"/>
    <user12Position>left</user12Position>
    <letRingFontFace>MuseJazz Text</letRingFontFace>
    <letRingFontSize>10</letRingFontSize>
    <letRingLineSpacing>1</letRingLineSpacing>
    <letRingFontSpatiumDependent>1</letRingFontSpatiumDependent>
    <letRingFontStyle>0</letRingFontStyle>
    <letRingColor r="0" g="0" b="0" a="255"/>
    <letRingTextAlign>left,center</letRingTextAlign>
    <letRingHookHeight>0.6</letRingHookHeight>
    <letRingPlacement>1</letRingPlacement>
    <letRingPosAbove x="0" y="0"/>
    <letRingPosBelow x="0" y="0"/>
    <letRingLineWidth>0.15</letRingLineWidth>
    <letRingLineStyle>dashed</letRingLineStyle>
    <letRingDashLineLen>5</letRingDashLineLen>
    <letRingDashGapLen>5</letRingDashGapLen>
    <letRingText>let ring</letRingText>
    <letRingFrameType>0</letRingFrameType>
    <letRingFramePadding>0.2</letRingFramePadding>
    <letRingFrameWidth>0.1</letRingFrameWidth>
    <letRingFrameRound>0</letRingFrameRound>
    <letRingFrameFgColor r="0" g="0" b="0" a="255"/>
    <letRingFrameBgColor r="255" g="255" b="255" a="0"/>
    <letRingPosition>left</letRingPosition>
    <letRingEndHookType>3</letRingEndHookType>
    <palmMuteFontFace>MuseJazz Text</palmMuteFontFace>
    <palmMuteFontSize>10</palmMuteFontSize>
    <palmMuteLineSpacing>1</palmMuteLineSpacing>
    <palmMuteFontSpatiumDependent>1</palmMuteFontSpatiumDependent>
    <palmMuteFontStyle>0</palmMuteFontStyle>
    <palmMuteColor r="0" g="0" b="0" a="255"/>
    <palmMuteTextAlign>left,center</palmMuteTextAlign>
    <palmMuteHookHeight>0.6</palmMuteHookHeight>
    <palmMutePlacement>1</palmMutePlacement>
    <palmMutePosAbove x="0" y="-4"/>
    <palmMutePosBelow x="0" y="4"/>
    <palmMuteLineWidth>0.15</palmMuteLineWidth>
    <palmMuteLineStyle>dashed</palmMuteLineStyle>
    <palmMuteDashLineLen>5</palmMuteDashLineLen>
    <palmMuteDashGapLen>5</palmMuteDashGapLen>
    <palmMuteText>P.M.</palmMuteText>
    <palmMuteFrameType>0</palmMuteFrameType>
    <palmMuteFramePadding>0.2</palmMuteFramePadding>
    <palmMuteFrameWidth>0.1</palmMuteFrameWidth>
    <palmMuteFrameRound>0</palmMuteFrameRound>
    <palmMuteFrameFgColor r="0" g="0" b="0" a="255"/>
    <palmMuteFrameBgColor r="255" g="255" b="255" a="0"/>
    <palmMutePosition>left</palmMutePosition>
    <palmMuteEndHookType>3</palmMuteEndHookType>
    <fermataPosAbove x="0" y="-0.5"/>
    <fermataPosBelow x="0" y="0.5"/>
    <fermataMinDistance>0.4</fermataMinDistance>
    <fingeringPlacement>0</fingeringPlacement>
    <articulationMinDistance>0.4</articulationMinDistance>
    <fingeringMinDistance>0.5</fingeringMinDistance>
    <hairpinMinDistance>0.7</hairpinMinDistance>
    <letRingMinDistance>0.7</letRingMinDistance>
    <ottavaMinDistance>0.7</ottavaMinDistance>
    <palmMuteMinDistance>0.7</palmMuteMinDistance>
    <pedalMinDistance>0.7</pedalMinDistance>
    <repeatMinDistance>0.5</repeatMinDistance>
    <textLineMinDistance>0.7</textLineMinDistance>
    <systemTextLineMinDistance>0.7</systemTextLineMinDistance>
    <trillMinDistance>0.5</trillMinDistance>
    <vibratoMinDistance>1</vibratoMinDistance>
    <voltaMinDistance>1</voltaMinDistance>
    <figuredBassMinDistance>0.5</figuredBassMinDistance>
    <tupletMinDistance>0.5</tupletMinDistance>
    <slurShowTabSimple>1</slurShowTabSimple>
    <slurShowTabCommon>1</slurShowTabCommon>
    <fermataShowTabSimple>1</fermataShowTabSimple>
    <fermataShowTabCommon>1</fermataShowTabCommon>
    <dynamicsShowTabSimple>1</dynamicsShowTabSimple>
    <dynamicsShowTabCommon>1</dynamicsShowTabCommon>
    <hairpinShowTabSimple>1</hairpinShowTabSimple>
    <hairpinShowTabCommon>1</hairpinShowTabCommon>
    <accentShowTabSimple>1</accentShowTabSimple>
    <accentShowTabCommon>1</accentShowTabCommon>
    <staccatoShowTabSimple>1</staccatoShowTabSimple>
    <staccatoShowTabCommon>1</staccatoShowTabCommon>
    <harmonicMarkShowTabSimple>1</harmonicMarkShowTabSimple>
    <harmonicMarkShowTabCommon>1</harmonicMarkShowTabCommon>
    <letRingShowTabSimple>1</letRingShowTabSimple>
    <letRingShowTabCommon>1</letRingShowTabCommon>
    <palmMuteShowTabSimple>1</palmMuteShowTabSimple>
    <palmMuteShowTabCommon>1</palmMuteShowTabCommon>
    <rasgueadoShowTabSimple>1</rasgueadoShowTabSimple>
    <rasgueadoShowTabCommon>1</rasgueadoShowTabCommon>
    <mordentShowTabSimple>1</mordentShowTabSimple>
    <mordentShowTabCommon>1</mordentShowTabCommon>
    <turnShowTabSimple>1</turnShowTabSimple>
    <turnShowTabCommon>1</turnShowTabCommon>
    <wahShowTabSimple>1</wahShowTabSimple>
    <wahShowTabCommon>1</wahShowTabCommon>
    <golpeShowTabSimple>1</golpeShowTabSimple>
    <golpeShowTabCommon>1</golpeShowTabCommon>
    <tabShowTiedFret>0</tabShowTiedFret>
    <tabParenthesizeTiedFret>0</tabParenthesizeTiedFret>
    <parenthesizeTiedFretIfArticulation>1</parenthesizeTiedFretIfArticulation>
    <tabFretPadding>0.1</tabFretPadding>
    <chordlineThickness>0.16</chordlineThickness>
    <dummyMusicalSymbolsScale>1</dummyMusicalSymbolsScale>
    <autoplaceEnabled>1</autoplaceEnabled>
    <defaultsVersion>302</defaultsVersion>
    <changesBeforeBarlineRepeats>0</changesBeforeBarlineRepeats>
    <changesBeforeBarlineOtherJumps>0</changesBeforeBarlineOtherJumps>
    <placeClefsBeforeRepeats>0</placeClefsBeforeRepeats>
    <changesBetweenEndStartRepeat>1</changesBetweenEndStartRepeat>
    <showCourtesiesRepeats>0</showCourtesiesRepeats>
    <useParensRepeatCourtesies>1</useParensRepeatCourtesies>
    <showCourtesiesOtherJumps>0</showCourtesiesOtherJumps>
    <useParensOtherJumpCourtesies>1</useParensOtherJumpCourtesies>
    <showCourtesiesAfterCancellingRepeats>0</showCourtesiesAfterCancellingRepeats>
    <useParensRepeatCourtesiesAfterCancelling>1</useParensRepeatCourtesiesAfterCancelling>
    <showCourtesiesAfterCancellingOtherJumps>0</showCourtesiesAfterCancellingOtherJumps>
    <useParensOtherJumpCourtesiesAfterCancelling>1</useParensOtherJumpCourtesiesAfterCancelling>
    <smallParens>1</smallParens>
    <repeatPlayCountPreset>nx</repeatPlayCountPreset>
    <repeatPlayCountShow>0</repeatPlayCountShow>
    <repeatPlayCountShowSingleRepeats>0</repeatPlayCountShowSingleRepeats>
    <systemObjectsBelowBottomStaff>0</systemObjectsBelowBottomStaff>
    <spatium>1.7018</spatium>
    </Style>
  </museScore>
